#include "pseudo_node.h"

#include "agent.h"
#include "constraint.h"
#include "relation.h"
#include "var_int.h"

PseudoNode::PseudoNode( Agent* _content, PseudoNode* _parent )
  : content( _content ) , parent( _parent ), locked( false )
{ }//-

PseudoNode::~PseudoNode() 
{ }//-

PseudoNode::PseudoNode( const PseudoNode& other )
{
  content = other.content;
  parent = other.parent;
  children = other.children;
  locked = other.locked;
}//-

PseudoNode& PseudoNode::operator=( const PseudoNode& other )
{
  if( this != &other )
  {
    content = other.content;
    parent = other.parent;
    children = other.children;
    locked = other.locked;
  }
  return *this;
}//-

void PseudoNode::insertChild( PseudoNode *child )
{
  if( std::find ( children.begin(), children.end(),  
		  child ) == children.end() ) // not found
    children.push_back( child ); 
}//-

PseudoNode* PseudoNode::getParent()
{
  return parent;
}//-

std::vector<PseudoNode*> PseudoNode::getChildren()
{
  return children;
}//-

Agent* PseudoNode::getContent()
{
  return content;
}//-

bool PseudoNode::isLeaf() const
{
  return children.empty();
}//-

bool PseudoNode::isRoot() const
{
  return ( parent == NULL );
}//-

void PseudoNode::lock()
{
  locked = true;
}//-

void PseudoNode::unlock()
{
  locked = false;
}//-

bool PseudoNode::isLocked() const
{
  return locked;
}//-

void PseudoNode::dump() const
{
  std::cout << "Pseudonode: "
	    << content->get_name()
	    << std::endl;
  
  
}//-
