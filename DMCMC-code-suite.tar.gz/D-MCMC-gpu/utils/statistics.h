#ifndef STATISTICS_H
#define STATISTICS_H

#include "globals.h"

enum t_stats { t_sampling, t_init, t_comm, t_statistics, t_wasted, t_WALL_CLOCK, t_stat_size };

class Statistics
{
 private:
  timeval** time_stats;//[ t_stat_size ][ 150 ];  
  double t_limit;
  double t_total_limit;
  double** time_start;//[ t_stat_size ][ 150 ];
  double** time;//[ t_stat_size ][ 150 ];
  double** total_time;//[ t_stat_size ][ 150 ];
  int best_utility;
  
 public:
  Statistics(int argc, char* argv[]);
  ~Statistics();

  void reset(); 
  void set_timeout (double sec);
  void set_total_timeout (double sec);
  void set_timer (t_stats t, int agent_id=0);
  void force_set_time(t_stats t, int agent_id=0);
  double get_timer (t_stats t, int agent_id=0);
  double get_total_timer (t_stats t, int agent_id=0);
  void stopwatch (t_stats t, int agent_id=0);
  bool timeout (int a); 
  void set_best_utility( int u ); 
  int get_best_utility( ); 

  size_t getMaxRSS() const; 
  void dump( std::ostream &os=std::cout );
  void dump_csv (std::ostream &os=std::cout);
};

#endif
