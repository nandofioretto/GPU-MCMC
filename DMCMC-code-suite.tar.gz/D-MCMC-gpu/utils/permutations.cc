#include "permutations.h"

using namespace std;

// Creates permutation of k elements among range [0 n-1] 
Permutations::Permutations (int _n, int _k) 
  : n(_n), k(_k) 
{   
  vector<int> v (n);
  for (int i = 0; i < n; i++) 
    v[i] = i;

  vector<int> permutation;
  do {
    permutation.clear();
    permutation.reserve(k);
    for (int i = 0; i < k; i++)
      permutation.push_back (v[i]);
    
    if (permutations.empty() || 
	permutation != permutations[permutations.size()-1]) {
      permutations.push_back (permutation);
    }
  } while (next_permutation (v.begin(), v.end()));
  //g_radix_sort (permutations);
}//-

vector<int> 
Permutations::operator[] (int idx) const {
  return permutations[idx];
}//-

size_t
Permutations::size() const {
  return permutations.size();
}

int 
Permutations::get_n() const {
  return n;
}//-

int 
Permutations::get_k() const {
  return k;
}//-

void 
Permutations::dump() {
  for (int i=0; i<permutations.size(); i++) {
    for (int ii=0; ii<permutations[i].size(); ii++) {
      cout << permutations[i][ii] << " ";
    }
    cout << endl;
  }
}//-
