#ifndef IO_UTILITIES_
#define IO_UTILITIES_

#include "globals.h"

namespace io_utils
{
  void parse_input ( std::string xml_file );
  void dump_help();
};

#endif
