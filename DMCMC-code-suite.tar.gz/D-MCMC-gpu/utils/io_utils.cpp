#include "io_utils.h"
#include "domain.h"
#include "var_int.h"
#include "relation.h"
#include "constraint.h"
#include "agent.h"

#include "rapidxml.hpp"
using namespace std;
using namespace rapidxml;

//#define DBG_IO

void io_utils::parse_input ( std::string xml_file ) 
{
  string input_xml;
  string line;
  ifstream in( xml_file.c_str() );
  while( getline( in, line) )
    input_xml += line;

  // make a safe-to-modify copy of input_xml
  vector<char> xml_copy(input_xml.begin(), input_xml.end());
  xml_copy.push_back('\0');
  xml_document<> doc;
  doc.parse<parse_declaration_node | parse_no_data_nodes>( &xml_copy[ 0 ] );
  xml_node<>* root = doc.first_node("instance");
  xml_node<>* xpre = root->first_node("presentation");
  bool maximize = true;
  if( xpre->first_attribute("maximize") )
  { 
    std::string optMax = xpre->first_attribute("maximize")->value();
    if ( optMax.compare("true") == 0 )
      maximize = true;
    else 
      maximize = false;
  }
  xml_node<>* xagents = root->first_node("agents");
  xml_node<>* xagent   = xagents->first_node("agent");
  do
  {
    Agent *agent = new Agent( xagent );
    agent->set_opt ( maximize );
#ifdef DBG_IO
    agent->dump();
#endif
    xagent = xagent->next_sibling();
  } while ( xagent );

  // Parse and create domains
  xml_node<>* xdoms = root->first_node("domains");
  xml_node<>* xdom = xdoms->first_node("domain");
  do
  {
    Domain *dom = new Domain( xdom );
#ifdef DBG_IO
    dom->dump();
#endif
    xdom = xdom->next_sibling();
  } while ( xdom );

  // Parse and create variables
  xml_node<>* xvars = root->first_node("variables");
  xml_node<>* xvar = xvars->first_node("variable");
  do 
  {
    var_int *var = new var_int( xvar );
#ifdef DBG_IO
    var->dump();
#endif
    xvar = xvar->next_sibling();
  } while ( xvar );

  // Parse and create relations
  xml_node<>* xrels = root->first_node("relations");
  xml_node<>* xrel = xrels->first_node("relation");
  do
  {
    Relation *rel = new Relation( xrel );
#ifdef DBG_IO
    rel->dump();
#endif
    xrel = xrel->next_sibling();
  } while ( xrel); 

  // Parse and create constraints
  xml_node<>* xcons = root->first_node("constraints");
  xml_node<>* xcon  = xcons->first_node("constraint");
  do
  {
    Constraint *con = new Constraint( xcon );
#ifdef DBG_IO
    con->dump();
#endif
    xcon = xcon->next_sibling();
  } while ( xcon );


}//-


void io_utils::dump_help()
{
  std::cout << "GD-Gibbs Execution Instructions:\n";
  std::cout << "gd-gibbs -i <input_file> <nsamples> <nseeds> [-a <algorithm> -t <timout> ]\n"
	    << "\n"
	    << " -i options:\n"
	    << "    <input_file>: path to the xcsp file\n"
	    << "    <nsamples>: the number of iterations for the Gibbs sampling\n"
            << "    <nseeds>:   the number of random starting tuples for the Gibbs samplings\n"
	    << " -a options:\n"
	    << "    <algorithm>: gi (gibbs) | mh (metropolis hasting)\n"
	    << " -t options:\n"
	    << "    <timeout>:  the timeout in seconds\n";
}
