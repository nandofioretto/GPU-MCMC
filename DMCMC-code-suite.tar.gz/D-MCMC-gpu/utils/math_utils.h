#ifndef _MATH_UTILS_H
#define _MATH_UTILS_H

#include "globals.h"

namespace math {
  // round precision to the i-th decimal
  double round_to_zero (double x, unsigned int i);
}//-

#endif
