#ifndef RELATION_H
#define RELATION_H

#include "globals.h"
#include <rapidxml.hpp>

using namespace std;
using namespace rapidxml;


class Relation 
{
 private:
  std::string _name;
  size_t _id;
  int _arity;
  int _nb_tuples;
  std::string _semantics;
  int _def_cost;
 public:
  std::map< vector<int>, int > _utilities;
  std::map< vector<int>, int >::iterator _uit;

  int _shift; // at the beginning we trasnlate all the domain elments so that min(D) = 0. _shift is the magnitude of the translation
 
 public:
  Relation (rapidxml::xml_node<>* relation);
  Relation (const Relation& other);
  Relation& operator= (const Relation& other);
  ~Relation();
  bool operator== (const Relation& other);  // used by search functions
  bool operator< (const Relation& other);
  bool operator() (Relation& ci, Relation& cj);
  
  std::string get_name();
  size_t get_id();
  int get_arity();
  int get_ntuples();
  int get_def_cost();
  size_t sizeof_tuples();
  size_t sizeof_costs();

  int get_cost ( std::vector<int> tuple );
  std::vector<int> get_next_tuple( );
  std::vector<int> get_tuple( int pos );

  void set_uit_on_map_begin();
  bool is_uit_on_map_end();

  /* int* get_costs(); */
  /* int* get_tuples(); */
  void dump();
};

#endif
