#ifndef DEVICE_GIBBS_SAMPLING_H
#define DEVICE_GIBBS_SAMPLING_H

#include <stdio.h>
#include <string.h>

__global__ void 
dev_gibbs_sampling ( unsigned int rnd_seed, int b_sh, int nSeeds, int nIterGibbs, float t_limit );

__device__ bool 
__is_thread_valid(int n_GS_rows_on_this_block, int GS_row_idx, int nSeeds );

__device__ bool 
__contains( const int* S, const int n, const int x );

__global__ void 
dev_compute_joint_utility( int b_sh, int nSeeds );

__global__ void
dev_copy_samples( int *d_samples, int nsamples, int V, int nSeeds, int b_sh );

#endif
