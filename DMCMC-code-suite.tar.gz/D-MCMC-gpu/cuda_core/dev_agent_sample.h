#ifndef DEVICE_AGENT_SAMPLE_H
#define DEVICE_AGENT_SAMPLE_H

#include <stdio.h>
#include <string.h>

namespace dev_agent 
{
  void dev_gibbs( int X_size, int I_size, int D_size, int Aid, int nIterations,
		  int nskip, int nSeeds, long int* h_best_samples);

  void dev_metropolis_hasting_X( int X_size, int I_size, int D_size, int Aid, int nIterations,
			       int nskip, int nSeeds, long int* h_best_samples);


  void dev_metropolis_hasting( int X_size, int I_size, int D_size, int Aid, int nIterations,
			       int nskip, int nSeeds, long int* h_best_samples);

  void dev_block_metropolis_hasting( int X_size, int I_size, int D_size, int Aid, int nIterations,
				     int nskip, int nSeeds, long int* h_best_samples);

  void get_res_sampling( long int *outsample, long int nsamples, int X, int nSeeds);
  void compute_joint_utility( int nSamples, int nSeeds );

};

#endif
