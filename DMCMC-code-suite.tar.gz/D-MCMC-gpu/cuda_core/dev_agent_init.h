#ifndef DEVICE_AGENT_INIT_H
#define DEVICE_AGENT_INIT_H

#include "globals.h"

namespace dev_agent
{
  void initAgent(int dev_id,bool max,int dom_size,int l_size,int i_size,int n_seeds);
  void initGibbsSamples( int V, int I, int D, int nSeeds);
  void initConstraints( std::vector<var_int*> scope, int A_id );
  void free();
};

#endif
