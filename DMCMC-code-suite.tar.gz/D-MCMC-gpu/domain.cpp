#include "domain.h"
#include "var_int.h"
#include <rapidxml.hpp>

using namespace std;
using namespace rapidxml;

Domain::Domain( xml_node<>* dom ) 
  : _name( "" ), _values( NULL ), _state( NULL ), _size ( 0 ), v_ptr ( NULL ) 
{
  static size_t _g_CP_DOMAINS_COUNTER = 0;
  _id = _g_CP_DOMAINS_COUNTER++;
  _name  = dom->first_attribute("name")->value();
  _size  = atoi( dom->first_attribute("nbValues")->value() );
  _values = new int[ _size ];
  _state = new bool[ _size ];
  memset( _state, true, _size*sizeof( bool ) );
  
  string content = dom->value();
  size_t ival = content.find("..");
  if ( ival != std::string::npos)
  {
    _values[ 0 ] = atoi( content.substr(0, ival).c_str() ); 
    for( int i = 1; i < _size; i++)
    {
      _values[ i ] = _values[ i - 1 ] + 1;
    }
  }
  else
  {
    stringstream ss( content );
    int i = 0;
    while( i < _size )
    {
      ss >> _values[ i++ ];
    }
  }
  _min = 0;
  _max =  _size - 1;

  g_domains[ _name ] = this;

}//-


Domain::Domain ( size_t size ) 
  : _values( NULL ), _state( NULL ), _size( size ),  v_ptr ( NULL ) 
{
  _min = 0; _max = size - 1;
  _values = new int[ size ];
  for( int i = 0; i < size; i++ )
    _values[ i ] = i;
  _state = new bool[ size ];
  memset( _state, true, size*sizeof( bool ) );
}//-

Domain::Domain( int min, int max ) 
  : _values( NULL ), _state( NULL ), v_ptr ( NULL ) 
{
  assert( max >= min );
  _size = max - min + 1;
  _min = 0, max = _size - 1;
  _values = new int[ _size ];
  for( int i = 0, k = min; k <= max; i++, k++ )
    _values[ i ] = k;
  _state = new bool[ _size ];
  memset( _state, true, _size*sizeof( bool ) );
}//-

Domain::Domain( const Domain& other ) 
{
  _size = other._size;
  _min = other._min;
  _max = other._max;
  v_ptr = other.v_ptr;
  _values = new int[ _size ];
  memcpy( _values, other._values, _size * sizeof( int ) );
  _state = new bool[_size];
  memcpy( _state, other._state, _size * sizeof( bool ) );  
}//-

Domain::~Domain () 
{
  if( _values != NULL ) delete[] _values;
  if( _state != NULL )  delete[] _state;
}//-

Domain& Domain::operator= (const Domain& other) 
{
  if( this != &other )
  {
    if( _size != other._size )
    {
      _size = other._size;
      if( _state != NULL ) delete[] _state;
      _state = new bool[ _size ];
      if( _values != NULL ) delete[] _values;
      _values = new int[ _size ];
    }
    _min = other._min;
    _max = other._max;
    v_ptr = other.v_ptr;
    memcpy( _values, other._values, _size * sizeof( int ) );
    memcpy( _state, other._state, _size * sizeof( bool ) );  
  }
  return *this;
}//-

int  Domain::operator [] (size_t pos) const
{
  return _values[ pos ];
}//-

int& Domain::operator [] (size_t pos)
{
  return _values[ pos ];
}//-

int Domain::get_min () const 
{
  return _values[ _min ];
}//-

int Domain::get_max () const 
{
  return _values[ _max ];
}//-

void Domain::set_state( bool* other_state ) 
{
  memcpy( _state, other_state, _size * sizeof( bool ) );
}//-

bool* Domain::get_state () 
{
  return _state;
}//-

int* Domain::get_values()
{
  return _values;
}//-

void Domain::set( size_t pos ) 
{
  _state[ pos ] = true;
  if( _min == -1 || _min > pos )  _min = pos;
  if( _max == -1 || _max < pos ) _max = pos;
}//-

void Domain::set() 
{
  memset( _state, true, _size * sizeof( bool ) );
  _min = 0;
  _max = _size - 1;
}//-

void Domain::unset( size_t pos ) 
{
  _state[ pos ] = false;
  if( _min == pos ) // set new min
  {
    for( int i = _min + 1; i <= _max; i++ ) 
      if ( _state[ i ] ) { _min = i; break; }
  }
  if( _max == pos ) // set new max
  {
    for( int i = _max - 1; i >= _min; i-- ) 
      if ( _state[ i ] ) { _max = i; break; }
  }
  if( _min == pos && _max == pos) // domain is now empty 
  {
    _min = -1; 
    _max = -1;
  }
}//-

void Domain::unset() 
{
  memset( _state, false, _size * sizeof( bool ) );
  _min = _max = -1;
}//-

bool Domain::is_valid( size_t pos ) const 
{
  return _state[ pos ];
}

void Domain::set_singleton( size_t pos )
{
  unset();
  set( pos );
}

bool Domain::is_singleton() const
{
  return _min == _max;
}

bool Domain::is_empty() const
{
  return _max == -1;
}

size_t Domain::size() const
{
  return _size;
}

// inefficient find
int Domain::find( int target ) const
{
  for( int i = 0; i < _size; i++ )
    if( _values[ i ] == target )
      return i;
  return -1;
}//-

void Domain::dump() 
{
  // assert (v_ptr);
  int l = 0;// v_ptr->get_value();
  int i = 0;
  std::cout << "{";
  for (; i < _size - 1; i++) 
  {
    if (i % 20 == 19) std::cout << std::endl;
    else if( _values[ i ] == l ) std::cout << "[" << _values[ i ] << "], ";
    else if ( _state[ i ] ) {std::cout << _values[ i ] << ", ";}
  }
  if (_values[ i ] == l) std::cout << "[" << _values[ i ] << "]";
  if ( _state[ i ] ) std::cout << _values[ i ]; 
  std::cout << "}\n";
}//-
