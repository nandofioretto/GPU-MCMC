#include "constraint.h"
#include "var_int.h"
#include "relation.h"
#include <rapidxml.hpp>

using namespace std;
using namespace rapidxml;

Constraint::Constraint( xml_node<>* constraint )
  : _name( "" ), _arity( 0 ), _reference( NULL ), scope( NULL )
{
  static size_t _g_CP_CONSTRAINT_COUNTER = 0;
  _id = _g_CP_CONSTRAINT_COUNTER++;

  // Read Constraint Properties
  _name  = constraint->first_attribute("name")->value();
  _arity = atoi( constraint->first_attribute("arity")->value() );
  string p_scope = constraint->first_attribute("scope")->value();
  string p_ref = constraint->first_attribute("reference")->value();
  scope = new var_int*[ _arity ];
  
  _reference = g_relations[ p_ref ];

  stringstream ss( p_scope);
  int c = 0;
  string var;
  while( c < _arity )
  {    
    ss >> var;
    scope[ c++ ] = g_variables[ var ];
    g_variables[ var ]->add_constraint( this );
  }
  g_constraints[ _name ] = this;

}//-

Constraint::Constraint (const Constraint& other)
{
  
  scope = new var_int*[ other._arity ];
  _id     = other._id;
  _name   = other._name; 
  _arity  = other._arity;
  _reference = other._reference;
  
  memcpy( scope, other.scope, _arity * sizeof( var_int* ) ); 
}//-

Constraint& Constraint::operator= (const Constraint& other)
{
  if( this != &other )
  {
    if ( _arity != other._arity ) { 
      delete[] scope;
      scope = new var_int*[ other._arity ];
    }
    _id     = other._id;
    _name   = other._name; 
    _arity  = other._arity;
    _reference = other._reference;
    
    memcpy( scope, other.scope, _arity * sizeof( var_int* ) ); 
  }
  return *this;
}//-

Constraint::~Constraint()
{
  delete[] scope;
}//-

bool Constraint::operator< (const Constraint& other) 
{
  return _id < other._id;
}//-

size_t Constraint::get_id()
{
  return _id; 
}

string Constraint::get_name() 
{
  return _name;
}

int Constraint::get_arity() 
{
  return _arity; 
}

Relation* Constraint::ref_relation()
{
  return _reference;
}

var_int* Constraint::ref_scope( size_t pos )
{
  return scope[ pos ];
}//-
var_int** Constraint::get_scope()
{
  return scope;
}//-

vector<int> Constraint::get_vars() 
{
  vector<int> ret( _arity );
  for( int i = 0; i < _arity; i++ )
    ret[ i ] = scope[ i ]->get_id();
  return ret;
}

bool Constraint::has_in_scope( var_int* v) 
{
  for( int i = 0; i < _arity; i++ )
    if( scope[ i ]->get_id() == v->get_id() )
      return true;
  return false;
}


void Constraint::dump() {
  std::cout << "Constraint: " << _name << " arity: " << _arity << " scope: ";
  for (int i = 0; i < _arity; i++ ) {
    std::cout << scope[ i ]->get_id() << ", ";
  }
  std::cout << std::endl;
  _reference->dump();
  
}//-
