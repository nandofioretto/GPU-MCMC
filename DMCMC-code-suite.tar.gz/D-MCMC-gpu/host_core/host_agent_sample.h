#ifndef HOST_AGENT_SAMPLE_H
#define HOST_AGENT_SAMPLE_H

#include <stdio.h>
#include <string.h>

namespace host_agent 
{

  void gibbs_sampling
    ( int X_size, int I_size, int D_size,  int nIterations, 
      int nSeeds, int* h_best_samples, int Aid );

};

#endif
