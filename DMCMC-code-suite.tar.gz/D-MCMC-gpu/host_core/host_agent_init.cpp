#include "host_agent_init.h"
#include "globals.h"
#include "host_globals.h"
#include "permutations.h"
#include "agent.h"
#include "constraint.h"
#include "relation.h"
#include "var_int.h"
#include "domain.h"

//#define DBG

using std::vector;
using std::map;
using std::string;

bool _allScopeCovered(Constraint*, int);
var_int* _lookupVar(vector<var_int*>, int);

void host_agent::dumpAgent( int i )
{
  printf(" A_%d.dev=%d\n", i, cudaAgent.device_id);
  printf(" A_%d.L=%d\n", i, cudaAgent.local_vars_size);
  printf(" A_%d.I=%d\n", i, cudaAgent.in_vars_size);
  printf(" A_%d.Nsample=%d\n", i, cudaAgent.n_samples);
  printf(" A_%d.Nseeds=%d\n", i, cudaAgent.n_seeds);
  printf(" A_%d.CA=%d\n", i, cudaAgent.n_constr);
}

/* To be called only once for all Agents */
void host_agent::initAgent
( int dev_id, bool max, int dom_size, int l_size, int i_size, int n_seeds )
{
  int ot = max ? _maximize : _minimize ;
  g_host_opt = ot;
  g_host_dom_size = dom_size;

  cudaAgent.device_id = dev_id;
  cudaAgent.opt_type = ot;
  cudaAgent.dom_size = dom_size;
  cudaAgent.local_vars_size = l_size;
  cudaAgent.in_vars_size = i_size;
  cudaAgent.n_seeds = n_seeds;
  
  cudaAgent.samples = NULL;
  cudaAgent.n_samples = -1;
  cudaAgent.constr = NULL;
  cudaAgent.n_constr = -1;
  //cudaAgent.constr_scope = NULL;
  // cudaAgent.constr_utils = NULL;   
}//-


void host_agent::initGibbsSamples( int V, int I, int D, int nSeeds)
{
  Permutations perm( D, I );
  int ntuples = perm.size();
  int TABLE_size = ntuples * ( V + 1 );

  cudaAgent.samples = new int[nSeeds * TABLE_size];
  cudaAgent.n_seeds = nSeeds;
  cudaAgent.n_samples = ntuples;
  int def_cost = (g_host_opt == _minimize) ? INFTY : -INFTY;
 
  for( int s = 0; s < nSeeds; s++ )
  {
    int SEED = s * TABLE_size;
    for( int k = 0; k < ntuples; k++ )
    {
      int SAMPLE = SEED + (k * (V + 1));
      memcpy(&cudaAgent.samples[SAMPLE],&perm.get_permutations()[k*I],I*sizeof(int));
      memset(&cudaAgent.samples[SAMPLE+I],-1,(V-I+1)*sizeof(int));
      /* Int Cost */
      cudaAgent.samples[SAMPLE+V] = def_cost;
    }
  }

#ifdef DBG
  for( int s = 0; s < nSeeds; s++ )
  {
    int SEED = s*ntuples*(V+1);
    printf("(DEVICE) SAMPLES (seed %d):\n", s);
    for( int k = 0; k < ntuples; k++ ) {
      int SAMPLE = k*(V+1);
      for( int i = 0; i < V; i++ )
	printf("%d ", cudaAgent.samples[SEED+SAMPLE+i]);
      printf("| %d \n",cudaAgent.samples[SEED+SAMPLE+V]);
    }
  }
  #endif
}//-



void host_agent::initConstraints( vector<var_int*> scope, int A_id )
{ 
  int X = scope.size();
  int D = g_host_dom_size;
  if( !g_host_constr_size) g_host_constr_size = new int[ g_agents.size() ];

  map< string, Constraint* >::iterator c_it =  g_constraints.begin();
  int counter = 0;
  for ( ; c_it != g_constraints.end(); ++c_it )
  {
    Constraint *C = c_it->second;
    int cid = C->get_id();
    if ( !_allScopeCovered( C, A_id ) ) continue;
    counter ++;
  }//-
  cudaAgent.n_constr    = counter;
  g_host_constr_size[ A_id ] = counter;

  assert(counter > 0);

  cudaAgent.constr = new g_AgentDS_Constr[ counter ];

  c_it = g_constraints.begin();
  int curr_constr = 0;
  for ( ; c_it != g_constraints.end(); ++c_it )
  {
    Constraint *C = c_it->second;
    int cid = C->get_id();
    int C_arity = C->get_arity();
    Relation *R = C->ref_relation();

    if ( !_allScopeCovered( C, A_id ) ) continue;

    int *tuple = new int[ C_arity ];
    int *tuple_dlb = new int[ C_arity ];
    
    int util_size = std::pow(D, (double)C_arity);
    cudaAgent.constr[ curr_constr ].arity = C_arity; 
    cudaAgent.constr[ curr_constr ].scope = new int[ C_arity ];
    cudaAgent.constr[ curr_constr ].utils = new int[ util_size ];

    /* Popolate constraint scope with variable ids in the same order
     as the one held by the agent */ 
    for( int ci = 0; ci < C_arity; ci++ )
    {
      int xi = C->ref_scope( ci )->get_id();
      tuple_dlb[ ci ] = _lookupVar( scope, xi )->domain->get_min();
      
      for( int si = 0; si < scope.size(); si++ )
      {
	if( C->ref_scope(ci) == scope[ si ] ) {
	  cudaAgent.constr[ curr_constr ].scope[ ci ] = si;
	}
      }
    }
    /* Set def. cost. */
    for( int i=0; i < util_size; i++ ) {
      cudaAgent.constr[curr_constr].utils[i] = R->get_def_cost();
    }
    for( int t = 0; t < R->sizeof_costs(); t++ )
    {
      int cost = R->get_cost( R->get_tuple( t ) );
      for(int i=0; i<C_arity; i++)
	tuple[i] = R->get_tuple(t)[i] - tuple_dlb[i];
      cudaAgent.constr[curr_constr].utils[ g_hash_util( D, C_arity, tuple ) ] = cost;
      
    }
    curr_constr++;
    delete[] tuple;
    delete[] tuple_dlb;
  }


  int dom   = cudaAgent.dom_size;
  for(int cid=0; cid < cudaAgent.n_constr; cid++)
  {
    int arity = cudaAgent.constr[cid].arity;
    for( int i = 0; i < std::pow(dom, (double)arity); i++)
    {

      if( cudaAgent.constr[cid].utils[ i ] < 0 || 
	  ( cudaAgent.constr[cid].utils[ i ] > 100 && 
	    cudaAgent.constr[cid].utils[ i ] < INFTY))
	  cout << " Agent " << A_id << " const " << cid << endl;
    }
  }

#ifdef DBG
  if( A_id == 13)
  {
  int dom   = cudaAgent.dom_size;
  for(int cid=0; cid < cudaAgent.n_constr; cid++)
  {
    int arity = cudaAgent.constr[cid].arity;
    printf("dom %d arity %d \n", dom, arity );

    Permutations perm( dom, arity );
    int ntuples = perm.size();


    printf( "Agent %d - constraint %d - scope: ",A_id, cid);
    for( int a = 0; a < arity; a++ )
      std::cout << scope[ cudaAgent.constr[cid].scope[ a ] ]->get_name();
    printf("\n----------\n");
        
    for( int i = 0; i < std::pow(dom, (double)arity); i++)
    {
       for( int j=0; j<arity; j++) 
	printf("%d ", perm.get_permutations()[i*arity + j ]);
      printf(": ");
      printf("%d \n", cudaAgent.constr[cid].utils[ i ] );
    }
    printf("----------\n");
    getchar();
  }
  }
#endif

}//-



// check constr scope contains all and only variables within current agent
bool _allScopeCovered( Constraint* C, int A_id )
{
  for (int i = 0; i < C->get_arity(); i++)
  {
    var_int* v = C->ref_scope( i );
    if ( g_agents[ v->get_owner() ]->get_id() != A_id ) return false;
  }
  return true;
}//-

var_int* _lookupVar( vector<var_int*> vars, int id )
{
  for (int i=0; i<vars.size(); i++)
    if ( vars[ i ]->get_id() == id ) return vars[ i ];
  return NULL;
}

void host_agent::free()
{
  delete[] cudaAgent.samples;
  //delete[] g_host_constr_size;
  for( int i = 0; i < cudaAgent.n_constr; i++)
  {
    delete[] cudaAgent.constr[ i ].scope;
    delete[] cudaAgent.constr[ i ].utils;
  }
    delete[] cudaAgent.constr; 
  //   delete[] cudaAgent.constr_scope;
  // delete[]cudaAgent.constr_utils;

}
