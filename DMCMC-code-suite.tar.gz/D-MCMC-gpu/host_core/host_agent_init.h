#ifndef HOST_AGENT_INIT_H
#define HOST_AGENT_INIT_H

#include "globals.h"

class var_int;

namespace host_agent
{
  void dumpAgent( int i );
  void initAgent(int dev_id,bool max,int dom_size,int l_size,int i_size,int n_seeds);
  void initGibbsSamples( int V, int I, int D, int nSeeds);
  void initConstraints( std::vector<var_int*> scope, int A_id );
  void free();
};

#endif
