#include "host_agent_sample.h"
#include "globals.h"
#include "host_globals.h"

//#define DBG

void __dump_samples__ (void);
bool __is_var_in_constr__ (int, int);
int __get_util__ (int, int*);
int __get_util__ (int, int*, int, int);
int *__tuple; // tmp variable used in __get_util__

/***
 * *
 ***/
void hostSampleCurrVar( int* best_sample, 
			int x_sample, int seed, int nSeeds, int row, int nSamples )
{

  int D = cudaAgent.dom_size;
  int X = cudaAgent.local_vars_size;
  int I = cudaAgent.in_vars_size;
  // int *CA_ids = cudaAgent.constr_scope;
  int C_A = cudaAgent.n_constr;
  int opt_cond = cudaAgent.opt_type;

  int SEED_S = seed * nSamples*(X+1);
  int SAMPLE = row*(X+1);
  int *curr_sample = &cudaAgent.samples[ SEED_S + SAMPLE ];

  double *P = new double[ D ];
  double _Zinv = 0.0;

  ///
  // Normalization Constant
  ///
  for (int d = 0; d < D; d++ )
  {
    int u = 0;
    int i_acc = 0;
    for(int c = 0; c < C_A; c++ )
    {
      if( __is_var_in_constr__ ( x_sample, c ) )
      { 
	u = __get_util__( c, curr_sample, x_sample, d );
	if ( u == INFTY || u == -INFTY) { continue; }
	i_acc += u;
      }
    }
    P[ d ] = (i_acc > 0 ) ? exp( (double)i_acc ) : 1.0;
    _Zinv += P[ d ];
  }
  _Zinv = (1 / _Zinv );
 
  ///
  // Probabilites and update current sample
  ///
  for (int d = 0; d < D; d++ ) P[ d ] *= _Zinv; 

  /* Choose a value for x -- based on prob. P */
  double x_rand_choice = ( ( double )( rand() % 1000000 ) / (double)1000000); 
  double Pacc = 0; int d = -1;
  do {
    Pacc += P[ ++d ];
  } while ( x_rand_choice >= Pacc && d < (D-1) ); 
  /* and save it in the output state */
  curr_sample[ x_sample ] = (d < D) ? d : (D-1);
  
  int i_acc = 0, u = 0;
  /* Scan each constraint involved in A (i.e., which has all the variables
     in its scope in A) */
  for(int c = 0; c < C_A; c++ )
    {
      u = __get_util__( c, curr_sample );
      if ( u == INFTY || u == -INFTY) { i_acc = u; break; }
      i_acc += u;
    }
  curr_sample[ X ] = i_acc;
  
  ///
  // Save Best Sample
  ///
  if( (opt_cond==_maximize && i_acc > best_sample[ X-I ] ) ||
      (opt_cond==_minimize && i_acc < best_sample[ X-I ] ) )
    {
      for (int c = I; c < X; c++)
	best_sample[ c - I ] = curr_sample[ c ];
      best_sample[ X-I ] = i_acc;
    }
  delete[] P;
}//-

bool is_better( int cost_a, int cost_b )
{
  int opt_cond = cudaAgent.opt_type;
  if( (opt_cond==_maximize && cost_a > cost_b) ||
      (opt_cond==_minimize && cost_a < cost_b ) )
    return true;
  return false;
}

// ignore scope and in_vars at this stage [but we need to check 
// whether the scope and inputs are always the same]
void host_agent::gibbs_sampling
( int X_size, int I_size, int D_size, int nIterations, 
  int nSeeds, int* h_best_samples, int Aid )
{
  __tuple = new int[ X_size ];

  /* samples is the number of possible tuples assigned to the InputVars */
  int samples  = pow( D_size, I_size );
  int *best_sample = new int[ X_size - I_size + 1];
  
  /* Init The Random value assignment for all the variables in V \ I */
  for (int s = 0; s < nSeeds; s++ )
  {
    int SEED = s * samples*(X_size+1);
    for( int row = 0; row < samples; row++)
    {
      int SAMPLE = row * (X_size+1);
      int Sidx_COST = SEED+SAMPLE+X_size;
      int Bidx_COST = X_size - I_size;
	
      // Random Initial configuration
      for ( int x = I_size; x < X_size; x++ )
      {
	cudaAgent.samples[ SEED + SAMPLE + x ] = (int)(rand() % D_size); 
      }
      best_sample[ Bidx_COST ] = cudaAgent.samples[ Sidx_COST ];
      
      // Sampling distrib
      for( int t = 0; t < nIterations; t++ )
      {
	for ( int x = I_size; x < X_size; x++ )
	{
	  //printf("sample %d\titeration %d - var %d\n", row, t, x );
	  hostSampleCurrVar( best_sample, x, s, nSeeds, row, samples );
	  // __dump_samples__ ();
	  // getchar();
	}
	//if( g_stats->timeout( Aid ) ) break;
      }
      
      if( is_better( best_sample[ Bidx_COST ],  cudaAgent.samples[ Sidx_COST ] ) )
      {
	memcpy(&cudaAgent.samples[ SEED + SAMPLE + I_size ],
	       best_sample, (X_size-I_size + 1) * sizeof(int) );
      }
    }//- rows
  }//- seeds
  delete[] best_sample;

  // Copy best samples back 
  int opt_cond = cudaAgent.opt_type;
  int best = opt_cond==_maximize ? -INFTY : INFTY;
  for( int row = 0; row < samples; row++)
  {
    int SAMPLE = row * (X_size+1);
    int BEST_SAMPLE = -1;
    for (int s = 0; s < nSeeds; s++ )
    {
      int SEED = s * samples * ( X_size + 1 );
      int Sidx_COST = SEED+SAMPLE+X_size;
      if( BEST_SAMPLE == -1 ) BEST_SAMPLE = SEED+SAMPLE; // assign first in case no better sample is found

      /* Check best */
      if( is_better( cudaAgent.samples[ Sidx_COST ], best ) )
      {
	best = cudaAgent.samples[ Sidx_COST ];
	BEST_SAMPLE = SEED + SAMPLE;
      }
    }
    assert(BEST_SAMPLE >= 0);
    memcpy( &h_best_samples[ SAMPLE ], 
	    &cudaAgent.samples[ BEST_SAMPLE ], ( X_size + 1 ) * sizeof(int) );

#ifdef DBG
    printf("Agent: %d\n", Aid);
    printf("[ ");
    for( int i = 0; i <= X_size; i++) 
    {
      if(i==I_size) printf("] ");
      if(i==X_size) printf(" : ");
      printf("%d ", h_best_samples[ SAMPLE + i ]);
    }
    printf("\n");
#endif
  }
#ifdef DBG
  getchar();
#endif
  delete[] __tuple;
  
}//-


bool __is_var_in_constr__ ( int var, int cid )
{
  int *scope = cudaAgent.constr[ cid ].scope;
  for( int i=0; i<cudaAgent.constr[ cid ].arity; i++)
    if( var == scope[i] ) return true;
  return false;
}//-

 int __get_util__ (int cid, int *sample, int var_sobst, int val_sobst )
 {
   // only extract subsequence relevant to this constraint
  int *scope = cudaAgent.constr[ cid ].scope;
  int a = cudaAgent.constr[ cid ].arity;
  for( int i=0; i<a; i++)
  {
    __tuple[i] = scope[i] == var_sobst ? val_sobst : sample[scope[i]];
  }
  return cudaAgent.constr[cid].utils[ g_hash_util( cudaAgent.dom_size, a, __tuple ) ];
 }//-

 int __get_util__ (int cid, int *sample )
 {
   // only extract subsequence relevant to this constraint
  int *scope = cudaAgent.constr[ cid ].scope;
  int a = cudaAgent.constr[ cid ].arity;
  for( int i=0; i<a; i++)
  {
    __tuple[i] = sample[scope[i]];
  }
  return cudaAgent.constr[cid].utils[ g_hash_util( cudaAgent.dom_size, a, __tuple ) ];
 }//-


void __dump_samples__ ()
{
  int D = cudaAgent.dom_size;
  int X = cudaAgent.local_vars_size;
  int I = cudaAgent.in_vars_size;
  int nSamples = cudaAgent.n_samples;
  int nSeeds   = cudaAgent.n_seeds;


  for( int s = 0; s < nSeeds; s++)
  {
    int SEED = s * nSamples*(X+1);
    printf("*** SEED %d ***\n", s );
    for (int r = 0; r < nSamples; r++ ) 
    {
      int SAMPLE = r*(X+1);
      printf ("GDsample %d: <", r);
      for (int i = 0; i < X; i++) 
      {
	printf("%d ", cudaAgent.samples[ SEED + SAMPLE + i ] );
      }
      printf("> %d \n", cudaAgent.samples[ SEED + SAMPLE + X ] );
    }
  }
}
