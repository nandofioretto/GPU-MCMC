#include "pseudo_tree.h"
#include "pseudo_node.h"
#include "agent.h"
#include "constraint.h"


using namespace std;

void makeSuccessors( Agent* A ); // Aux
bool orderAgentNeighboursAsc (Agent* LHS, Agent* RHS);
bool orderAgentNeighboursDesc (Agent* LHS, Agent* RHS);
bool orderPairSecAsc( std::pair<Agent*,int> LHS, std::pair<Agent*,int> RHS);
std::vector< Constraint* > get_binary( Agent* Ai, Agent* Aj );

PseudoTree::PseudoTree( )
{
  // create successors of each Agent
  map< string, Agent* >::iterator a_it = g_agents.begin();
  for( ; a_it != g_agents.end(); ++a_it)
  {
    makeSuccessors( a_it->second );
    _MarkedAgents[ a_it->second ] = -1;
  }
  
  // Order each agent successors via decreasing number of constraints
  map<Agent*,std::vector<Agent*> >::iterator n_it = 
    g_agent_neighbours.begin();
  for( n_it; n_it != g_agent_neighbours.end(); ++n_it)
    std::sort ( n_it->second.begin(), n_it->second.end(), orderAgentNeighboursAsc );

  // Order Agents via decreasing number of neighbours for the dfs search
  std::vector<std::pair<Agent*,int> > dfs_ordering;
  std::vector<std::pair<Agent*,int> > d_it;
  n_it = g_agent_neighbours.begin();
  for( ; n_it != g_agent_neighbours.end(); ++n_it)
  {
    dfs_ordering.push_back( make_pair( n_it->first, n_it->second.size() ) );
  }
  std::sort( dfs_ordering.begin(), dfs_ordering.end(), orderPairSecAsc );

  // call the DFS exploration for the PseudoTree construction
  for( int i = 0; i < dfs_ordering.size(); i++ )
  {
    if ( _MarkedAgents[ dfs_ordering[ i ].first ] == -1 )
    {
      PseudoNode* curr_node = new PseudoNode(dfs_ordering[ i ].first, NULL );
      _dfsStep( curr_node );
    }
  }
}//-

PseudoTree::~PseudoTree()
{ }//-


void PseudoTree::_dfsStep( PseudoNode* curr_node )
{
  static int lev = 0;
  Agent* curr_agent = curr_node->getContent();

  if( _MarkedAgents[ curr_agent ] > -1 ) return; 

  _MarkedAgents[ curr_agent ] = lev;
  if (curr_node) _unlockedNodes[ curr_node ] = false;

  // Recur
  int numof_neighbours = g_agent_neighbours[ curr_agent ].size();
  for( int i = 0; i < numof_neighbours; i++ )
  {
    Agent *succ_agent = g_agent_neighbours[ curr_agent ][ i ];
    // check if successor was already descendant of some other node
    if( _MarkedAgents[ succ_agent ] == -1 )
    {
      // Add parent + parent-child constraints
      std::vector< Constraint* > dep = get_binary( curr_agent, succ_agent );
      succ_agent->set_parent( curr_agent, dep );
      curr_agent->add_child( succ_agent, dep );
      
      PseudoNode *succ_node = new PseudoNode( succ_agent, curr_node );
      curr_node->insertChild( succ_node );
      
      lev++;
      _dfsStep( succ_node );
      lev--;
    }
    else if ( _MarkedAgents[ succ_agent ] < lev-1 )
    {
      std::vector< Constraint* > dep = get_binary( curr_agent, succ_agent );
      curr_agent->add_ancestor( succ_agent, dep );
    }
  }

}//-

void PseudoTree::unlockNode( PseudoNode* N )
{
  _unlockedNodes[ N ] = true;
}//-


vector<PseudoNode*> PseudoTree::getNodessReadyToSample()
{
  vector<PseudoNode*> res;
  std::map< PseudoNode*, bool >::iterator it = _unlockedNodes.begin();
  
  for( ; it != _unlockedNodes.end(); ++it )
  {
    if ( it->second ) continue;
    std::vector<PseudoNode*> children = it->first->getChildren();
    // check if all the children are unlocked
    bool can_unlock = true;
    for( int i=0; i<children.size(); i++ )
    {
      if( ! _unlockedNodes[ children[ i ] ] ) {
	can_unlock = false; break;
      }
    }
    if( can_unlock ) res.push_back( it->first );
  }
  return res;

}//-

std::vector< Constraint* > get_binary( Agent* Ai, Agent* Aj )
{
  std::vector< Constraint* > cons;

  for( int i = 0; i < Ai->invar_size(); i++ )
  {
    var_int* vi = Ai->get_var( i );
    // scan all constraint involving vi
    for( int c = 0; c < vi->numof_constraints(); c++ )
    {
      Constraint* Ci = vi->get_constraint( c );

      for( int j = 0; j < Aj->invar_size(); j++ )
      {
	var_int* vj = Aj->get_var( j );
	if( Ci->has_in_scope( vi ) && Ci->has_in_scope( vj ) )
	  if( find (cons.begin(), cons.end(), Ci) == cons.end() )
	    cons.push_back( Ci );
      }
    }
  }
  return cons;
}//-

// Aux function
void makeSuccessors( Agent* A )
{  
  std::vector<Agent*> neighbours;
  std::vector<Agent*>::iterator n_it;

  // get all constraints involving input variables of A
  for( int i = 0; i < A->invar_size(); i++ )
  {
    var_int* A_vi = A->get_var( i );
    for( int c = 0; c < A_vi->numof_constraints(); c++ )
    {
      Constraint* c_in_A = A_vi->get_constraint( c );

      for( int a = 0; a < c_in_A->get_arity(); a++ )
      {
	var_int* scope_c = c_in_A->ref_scope( a );
	std::string owner = scope_c->get_owner();
	if( owner != A->get_name() )
	{
	  if( find (neighbours.begin(), neighbours.end(),  
		    g_agents[ owner ]) == neighbours.end() ) // not found
	  {
	    neighbours.push_back( g_agents[ owner ] );
	  }
	}
      }//- arity of c_in_A
    }//- all c_in_A for input vars of A
  }//- all input vars of A
  
  g_agent_neighbours[ A ] = neighbours;
}


bool orderAgentNeighboursAsc (Agent* LHS, Agent* RHS) 
{
  return ( g_agent_neighbours[ LHS ].size() > 
	   g_agent_neighbours[ RHS ].size() ); 
}//-

bool orderAgentNeighboursDesc (Agent* LHS, Agent* RHS) 
{
  return ( g_agent_neighbours[ LHS ].size() <
	   g_agent_neighbours[ RHS ].size() ); 
}//-


bool orderPairSecAsc( std::pair<Agent*,int> LHS, std::pair<Agent*,int> RHS)
{
  return ( LHS.second > RHS.second );
}//-
