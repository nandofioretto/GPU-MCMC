#include "var_int.h"
#include "agent.h"
#include "domain.h"
#include "constraint.h"
#include <rapidxml.hpp>

using namespace std;
using namespace rapidxml;

var_int::var_int( xml_node<>* var ) 
  : _name( "" ), _owner ( "" ), _label( -1 ), 
    _assigned( false ), _changed ( false ), domain( NULL )
{
  static size_t _g_CP_VARIABLE_COUNTER = 0;
  _id = _g_CP_VARIABLE_COUNTER++;
  _name   = var->first_attribute("name")->value();
  _owner  = var->first_attribute("agent")->value();
  string p_dom = var->first_attribute("domain")->value();

  domain = g_domains[ p_dom ];
  domain->v_ptr = this;

  // Add reference to the agent owning this variable
  g_agents[ _owner ]->add_variable( this );

  // Add reference to Set of CP Variables
  g_variables[ _name ] = this;
}//-


var_int::var_int( const var_int& other )
{
  _id       = other._id;
  _name     = other._name;
  _owner    = other._owner;
  _label    = other._label;
  _assigned = other._assigned;
  _changed  = other._changed;
  // constraint_dependencies  = 
  //   other.constraint_dependencies;

  *domain = *(other.domain);
  domain->v_ptr = this;
}//-


var_int& var_int::operator=( const var_int& other )
{
  if ( this != &other )
  {
    _id       = other._id;
    _name     = other._name;
    _owner    = other._owner;
    _label    = other._label;
    _assigned = other._assigned;
    _changed  = other._changed;
    // constraint_dependencies  = 
    //   other.constraint_dependencies;
    
    *domain = *(other.domain);
    domain->v_ptr = this;
  }
  return *this;
}//-

var_int::~var_int () 
{
}//-

bool var_int::operator< ( const var_int& other ) 
{
  return _id < other._id;
}//-

bool var_int::operator== ( const var_int& other )
{
  return _id == other._id;
}

size_t var_int::get_id () const
{
  return _id;
}//-

void var_int::set_assigned () 
{
  if( !_assigned ) 
  {
    _assigned = true;
    _changed  = true;
  }
  // Insert this variable constraints in the CSTORE
  // g_constraint_store->upd_changed( this );
}//-

void var_int::unset_assigned () 
{
  _assigned = false;
}//-

bool var_int::is_assigned () const 
{
  return _assigned;
}//-

void var_int::set_changed () {
  _changed = true;
  // g_constraint_store->upd_changed (this);
}//-

void var_int::unset_changed() 
{
  _changed = false;
}//-

bool var_int::is_changed() const
{
  return _assigned;
}//-

bool var_int::is_failed() const
{
  return domain->is_empty();
}//-

void var_int::reset () {
  _label  = -1;
  _assigned = false;
  _changed  = false;
  domain->set();
}//-

void var_int::add_constraint( Constraint* c )
{
  constraints.push_back( c ); 
}//-

Constraint* var_int::get_constraint( int idx ) 
{
  return constraints[ idx ];
}//-

size_t var_int::numof_constraints() const 
{
  return constraints.size();
}//-

int var_int::get_value() 
{
  if( _label != -1 )
    return (*domain)[ _label ];
  return -1;
}//-

void var_int::set_label( int value )
{
    _label = value;
}

void 
var_int::dump () 
{
  std::cout << "var_int_" << _id << " ";
  std::cout << _name << " (" << _owner << ")  ";
  std::cout << "Label: " << _label << "\t";
  if( is_assigned() ) std::cout << " ASSIGNED ";
  if( is_failed() )   std::cout << " FAILED ";
  if( is_changed() )  std::cout << " CHANGED ";
  std::cout << "Dom: ";
  domain->dump();
}//-
