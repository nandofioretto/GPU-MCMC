#ifndef AGENT_H
#define AGENT_H

#include "var_int.h"
#include "globals.h"
#include "message.h"
#include <rapidxml.hpp>

using namespace std;

class var_int;
class Constraint;
class Message;

/* 
 * An agent represent a subset of variables of the DCOP problem. 
 * Each agent is in charge of selecting the values for its variables
 * trhough a GIBBS sampling process.  
 * An agent is concetually hosted on the DEVICE -- i.e., all its 
 * operations, but initializations and communication, are preformed on 
 * GPUs. The initialization phase is also responsable to allocate 
 * resources on the device.
 *
 * The scope is the set of variable that are sampled by this agent. The
 * first in_vars_size elements of 'scope' are the input variables. 
 * The random choices are initialized when the agent is created, on the 
 * HOST, as no rand() function can be used on the DEVICE. 
 */
class Agent
{

 private:
  size_t _id;
  string _name;
  vector< var_int* > scope;	/* variable scope */
  int in_vars_size;    /* Input variables (first elements of scope) */
  int _device;	       /* GPU device associated to this agent  */
  int _nseeds; /* The number of Different intial random configurations
		  for the Gibbs Sampling */

  /* Sampling support */
  long int *_best_samples;
  long int _n_best_samples;
  bool _optMax;

  /* PSEUDO-TREE support */
  vector< pair< Agent*, vector< Constraint* > > > _ancestors;
  vector< pair< Agent*, vector< Constraint* > > > _children;
  pair< Agent*, vector< Constraint* > > _parent;
  
  /* Message passing support */
  Message _VALUE_msg;  // to be sent to its parent
  Message _UTIL_msg;   

  vector< Message* > _received_VALUE_msgs;
  vector< Message* > _received_UTIL_msgs;
  long int _numof_received_VALUE_msgs;
  long int _numof_received_UTIL_msgs;
  
 public:
  Agent( rapidxml::xml_node<>* agent );
  ~Agent();

  void init( int dev, int _nseeds  );
  void free_global_DS();
  size_t get_id();
  string get_name();
  bool get_opt();
  var_int* get_var( int i );
  std::vector<var_int*> get_input_vars();
  vector< var_int* > get_input_vars_in( vector< Constraint* > con );

  int scope_size();
  int invar_size();
  void add_variable( var_int* v );
  void add_variables( );
  void set_opt( bool maximize );
  bool has_in_scope( var_int* v );

  /* Pseudo-tree operations */
  Agent* get_ancestor(int i);
  Agent* get_child(int i);
  Agent* get_parent();
  void add_child( Agent* c, vector< Constraint* > C );
  void add_ancestor( Agent* a, vector< Constraint* > C );
  void set_parent( Agent* p, vector< Constraint* > C );
  int n_ancestors();
  int n_children();
  bool is_root();
  bool is_leaf();
  
  void init_separtor_set();
  vector<var_int*> intersect_separator( Agent* other );
  void get_separator( vector<var_int*>& I, vector<var_int*>& S, 
		      vector<Constraint*>& C);

  /* Sampling */
  void sampling( int nsamles, int nskip, std::string alg );
  long int get_best_sample_util( long int i );

  /* Communication */
  bool send_VALUE_msg();
  bool recv_VALUE_msgs();
  Message* get_VALUE_msg();
  Message* get_received_VALUE_msg( long int i );

  bool send_UTIL_msg();
  bool recv_UTIL_msg();
  Message* get_UTIL_msg( long int i );

  /* Aux */
  void dump();
  void dump_best_samples();
  
};//-


#endif
