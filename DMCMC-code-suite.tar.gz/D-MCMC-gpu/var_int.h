/*********************************************************************
 * var_int 
 *********************************************************************/
#ifndef VAR_INT_H
#define VAR_INT_H

#include "globals.h"
#include <rapidxml.hpp>

class Domain;
class Constraint;

class var_int 
{
 private:
  size_t _id;
  std::string _name;
  std::string _owner;
  int _label;
  bool _assigned;
  bool _changed;
  // List of constraints to be checked after variable is changed
  std::vector < Constraint* > constraints;

 public:
  Domain *domain;

 public:
  var_int (rapidxml::xml_node<>* var);
  var_int( const var_int& other );
  var_int& operator=( const var_int& other );
  ~var_int();
  bool operator== ( const var_int& other );
  bool operator<( const var_int& other );

  std::string get_owner() const { return _owner; }
  std::string get_name()  const { return _name; }


  size_t get_id() const;
  bool is_failed() const;
  
  void set_assigned();
  void unset_assigned ();
  bool is_assigned () const;

  void set_changed ();
  void unset_changed ();
  bool is_changed () const;
  
  void reset();
  
  void add_constraint( Constraint* c );
  Constraint* get_constraint( int idx );
  size_t numof_constraints() const;
  
  void dump ();
  int get_value();
  void set_label( int value );
  
};//-

#endif
