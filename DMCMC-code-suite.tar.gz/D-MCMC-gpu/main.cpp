#include "globals.h"
#include "io_utils.h"
#include "agent.h"
#include "pseudo_tree.h"
#include "pseudo_node.h"
#include "domain.h"
#include "var_int.h"
#include "constraint.h"
#include "relation.h"
#include "permutations.h"

using namespace std;

#include <math.h>


int main (int argc, char* argv[])
{
  int _nsamples, _nseeds; string _input;
  string _sampling_alg = "gi";
  double _timeout;
  if (argc != 5 && argc != 7 && argc != 9 ) 
    { io_utils::dump_help(); exit(1); }
  
  for(int i = 0; i < argc; i++) 
  {
    if(!strcmp("-h", argv[i]) || !strcmp("--help", argv[i])) 
      { io_utils::dump_help(); exit(1); }
    if(!strcmp("-i", argv[i])) 
    { 
      _input = argv[++i];
      _nsamples = atoi(argv[++i]);
      _nseeds   = atoi(argv[++i]);
    }
    if(!strcmp("-a", argv[i]))
      _sampling_alg = argv[++i];
    if(!strcmp("-t", argv[i])) 
      _timeout = atof(argv[++i]);
  }
  
  io_utils::parse_input( _input );
  g_stats = new Statistics( argc, argv );
  g_stats->set_timer( t_WALL_CLOCK, 0 );

  g_dom_c = g_domains.begin()->second->size(); // not needed
  
  map< string, Agent* >::iterator a_it = g_agents.begin();
  for( ; a_it != g_agents.end(); ++a_it) 
  {
    a_it->second->add_variables( );// ok
  }

  /* PseudoTree construction */
  PseudoTree PT;
  vector<PseudoNode*> Nodes;
  vector<PseudoNode*> ret_nodes;
  int cc=0;
  do
  {
    //std::cout << "ROUND " << ++cc << std::endl;
    Nodes = PT.getNodessReadyToSample();
    ret_nodes.insert( ret_nodes.end(), Nodes.begin(), Nodes.end() );
    for( int i = 0; i < Nodes.size(); i++ )
    {
      Agent* A = Nodes[ i ]->getContent();
      /* INIT AGENT */  
      g_stats->set_timer( t_init, A->get_id() );
      A->init(0, _nseeds ); 
      g_stats->stopwatch( t_init, A->get_id() );

      /* SAMPLIING */
      g_stats->set_timer( t_sampling, A->get_id() );
      A->sampling( _nsamples, 0, _sampling_alg );
      g_stats->stopwatch( t_sampling, A->get_id() );

      g_stats->set_timer( t_init, A->get_id() );
      A->free_global_DS();
      g_stats->stopwatch( t_init, A->get_id() );
      
      PT.unlockNode( Nodes[ i ] ); // ...finish - unlock node
    }
  } while( ! Nodes.empty() );


  for(int i=0; i<ret_nodes.size(); i++)
  {
     Agent* A = ret_nodes[ i ]->getContent();
     // Solve Hard Constraints
     //A->
     // Propagate info into Agent sampling set

     // Sample 

     // (Send message)

     g_stats->set_timer( t_comm, A->get_id() );
     while( !A->recv_VALUE_msgs() ) { ; }
     A->send_VALUE_msg();
     g_stats->stopwatch( t_comm, A->get_id() );
   }

   g_stats->stopwatch( t_WALL_CLOCK, 0 );
   if( abs( g_stats->get_best_utility() ) == INFTY ) return -1;
   g_stats->dump_csv();
   return 0;

  /**************************************************************
   * Clear Memory 
   *************************************************************/
   delete g_stats;

  for ( std::map< std::string,Domain* >::iterator it = g_domains.begin();
   	it != g_domains.end(); ++it )
    delete it->second;

  for ( std::map< std::string,var_int* >::iterator it = g_variables.begin();
  	it != g_variables.end(); ++it )
    delete it->second;

  for ( std::map< std::string,Relation* >::iterator it = g_relations.begin();
  	it != g_relations.end(); ++it )
    delete it->second;

  for ( std::map< std::string,Constraint* >::iterator it = g_constraints.begin();
  	it != g_constraints.end(); ++it )
    delete it->second;

  // for ( std::map< std::string, Agent* >::iterator it = g_agents.begin();
  //  	it != g_agents.end(); ++it )
  //   delete it->second;

 
  return 0;
}//-
