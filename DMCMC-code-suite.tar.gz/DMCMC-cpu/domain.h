#ifndef DOMAIN_H
#define DOMAIN_H

#include "globals.h"
#include <rapidxml.hpp>

class var_int;

/*
 * Domain of integers
 */
class Domain 
{
 private:
  size_t _id;
  std::string _name;
  int *_values;
  bool *_state;
  size_t _size;
  int _min, _max; // idx of min and max active elements
   
 public:
  Domain( rapidxml::xml_node<>* dom );
  Domain( size_t size );
  Domain( int min, int max );
  Domain( const Domain& other );
  Domain& operator= (const Domain& other);
  ~Domain();
  int  operator [] (size_t pos) const;
  int& operator [] (size_t pos);

  var_int* v_ptr;

  // Domain Operations
  int get_min() const;
  int get_max() const;

  bool* get_state();
  void  set_state( bool* other_state );  
  int* get_values();

  void set( size_t pos );
  void set();
  void unset( size_t pos );
  void unset();
  bool is_valid( size_t pos ) const;
  bool is_empty() const;
  void set_singleton( size_t pos );
  bool is_singleton() const;

  int find( int target ) const;

  size_t size() const;
  void dump ();
};

#endif
