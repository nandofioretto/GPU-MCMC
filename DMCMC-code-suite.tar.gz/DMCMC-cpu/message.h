#ifndef MESSAGE_H
#define MESSAGE_H

#include "globals.h"

class Agent;
class Constraint;
class var_int;

typedef std::pair<Agent*,std::vector<Constraint*> > Agent_con;


class Message
{
 private:
 
  // contains the utility values for all the combinations of values
  // for the variables in the separator of the sender agent
  std::vector<var_int*> _header_sep_vars;
  std::vector<long int> _VALUE_msg;	/* the message content */
  Agent* _sender;
  Agent* _recver;

 public:

  Message();
  ~Message();
  Message( const Message& other );
  Message& operator=( const Message& other );

  Agent* get_sender();
  Agent* get_recver();
  bool is_empty();
  void set_header(Agent* sender, Agent_con parent, std::vector<Agent_con> ancestors);
  std::vector<var_int*> get_header();
  long int header_size();
  long int msg_size();
  long int get_utility(std::vector<int> query, int D );
  void get_query( std::vector<int>& query, std::vector<var_int*> query_vars, 
		  int D,
		  std::vector<var_int*> Sep_vars, long int sep_row, 
		  std::vector<var_int*> In_vars,  long int in_row, bool normalize );
  void get_query( std::vector<int>& query, var_int** query_vars, 
		  int query_vars_size, int D,
		  std::vector<var_int*> Sep_vars, long int sep_row, 
		  std::vector<var_int*> In_vars,  long int in_row, bool normalize );
  long int util_of_recv_VALUE_msgs( std::vector<var_int*> invars_A, long int i_a, 
			       std::vector<var_int*> invars_pA, long int i_pa );

  long int util_of_constrs (std::vector< Constraint* > constr_S_R, 
		       std::vector<var_int*> invars_S, long int i_s,
		       std::vector<var_int*> invars_R, long int i_r );
  void make ( Agent* sender, Agent_con parent, std::vector<Agent_con> ancestors );
  
};//-

#endif
