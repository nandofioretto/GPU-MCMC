#include "host_globals.h"

/* Structures Common to All Agents */
int g_host_opt;
int g_host_dom_size;
int* g_host_constr_size = NULL;
struct g_AgentDS;
g_AgentDS cudaAgent;


size_t g_hash_util( int d, int a, int T[])
{
  size_t ofs=0; size_t pos_i=0; int i;
  for(i=0; i<a; i++)
  {
    pos_i = std::pow(d, (double)(a-i-1));
    ofs  += T[i]*pos_i;
  }
  return ofs;
}

size_t g_hash_util( int d, int a, int T)
{
  return T;
}
