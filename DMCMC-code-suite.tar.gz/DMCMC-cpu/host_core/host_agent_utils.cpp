#include "host_agent_sample.h"
#include "globals.h"
#include "host_globals.h"

void _computeJointUtility( int nBlocks, int nThreads, int seed_id )
{
  int V = g_hostAgentScope_size;
  int F = 0;
  int SEED = seed_id * gh_outvals_utuples_size * (V+1);

  for ( int b = 0; b < nBlocks; b++ )
  { 
    int SAMPLE = b * (V+1);
    int *curr_sample = &gh_outvals_utuples[ SEED + SAMPLE ];
    F = 0;
#ifdef DBG
    std::cout<<"<";
    for( int i=0; i<V; i++) std::cout<<curr_sample[i]+1<<" ";
    std::cout<<">";
#endif

    /* Scan each constraint involved in A (i.e., which has all the variables
     in its scope in A) */
    for( int c = 0; c < g_hostAgentConstrIDs_size; c++ )
    {
      int u  = _getUtility( c, curr_sample ); 
      if ( u == INFTY || u == -INFTY) { F = u; break; }
      F += u;
    }

    curr_sample[ V ] = F;
#ifdef DBG
    std::cout << " " << F << std::endl;
#endif

    /* Check Opt */
    if( ( gh_optimization == _maximize && 
	  F > gh_best_outvals_utuples[ SEED + SAMPLE + V ] ) || 
	( gh_optimization == _minimize && 
	  F < gh_best_outvals_utuples[ SEED + SAMPLE + V ] )) 
    {
      memcpy( &gh_best_outvals_utuples[ SEED + SAMPLE ], 
	      curr_sample,  V * sizeof(int) );
      gh_best_outvals_utuples[ SEED + SAMPLE + V ] = F;
    }
  }//-end blocks
  // delete[] curr_sample;
}//-


void _cpyBestSamplesDevToHost( int *bestSampleOut, int nseeds )
{
  int V = g_hostAgentScope_size;
  int I = g_hostAgentInVar_size;
  int D = gh_domain_size;
  int ROWS = std::pow((double)D, (double)I);

  int best = (gh_optimization == _minimize) ? INFTY : -INFTY;
  int best_seed = -1;

  for( int r=0; r<ROWS; r++ )
  {
    int SAMPLE = r * ( V + 1 );
    best = -1; best_seed = 0;
 
    for( int s=0; s<nseeds; s++ )
    {
      int SEED = s * ROWS * (V + 1);
      int* sample = &gh_best_outvals_utuples[ SEED + SAMPLE ];       
      if( ( gh_optimization == _maximize && sample[ V ] > best) ||
	  ( gh_optimization == _minimize && sample[ V ] < best) )
      {
	best = sample[ V ]; best_seed = SEED;
      }
    }//-seeds

    memcpy( &bestSampleOut[ SAMPLE ], 
	    &gh_best_outvals_utuples[ best_seed + SAMPLE ],
	    (V + 1) * sizeof( int ) );
  }//-rows

}//-

int _get_best_sample() 
{
  int V = g_hostAgentScope_size;
  int I = g_hostAgentInVar_size;
  int D = gh_domain_size;
  int NROWS =std::pow((double)D, (double)I);
  int row = 0;
  int best = (gh_optimization == _minimize) ? INFTY : -INFTY;

  for (int r = 0; r < NROWS; r++ ) 
  {
    if( ( gh_optimization == _maximize 
	  && gh_best_outvals_utuples[ r * (V+1) + V ] > best) ||
      ( gh_optimization == _minimize
	&& gh_best_outvals_utuples[ r * (V+1) + V ] < best) )
    {
      row = r;
      best = gh_best_outvals_utuples[ r * (V+1) + V ];
   }
  }
  return best;
}


int _getUtility( int c, int *curr_sample )
{
  int D = gh_domain_size;
  int cinfo_idx = g_hostAgentConstrIDs[ c ];
  s_ConstraintInfo *c_info = &g_hostAgentConstrInfo[ cinfo_idx ];
  int Vi = c_info->scope[ 0 ];
  int Vj = c_info->scope[ 1 ];
  // Assicurati che siano salvati con gli ID che iniziano da 0 per lo
  // scope di questo agente. ok!
  int di = curr_sample[ Vi ];
  int dj = curr_sample[ Vj ];
  return c_info->costs[ di*D + dj ];
}



void _dump_gh_outvals() 
{
  int V = g_hostAgentScope_size;
  int I = g_hostAgentInVar_size;
  int D = gh_domain_size;
  int ROWS = std::pow((double)D, (double)I);

  for (int v = 0; v < ROWS; v++ ) 
  {
    printf ("GDsample %d: <", v);
    for (int i = 0; i < V; i++) 
    {
      int d_idx = gh_outvals_utuples[ v * ( V+1 ) + i ];
      printf ("%d ", g_hostAgentVarInfo[ i ].domain[ d_idx ] );
    }
    int val = gh_outvals_utuples[ v * (V+1) + V ]; 
    printf("> %d \n", val );
  }
}

void _dump_gh_outvals_best() 
{
  int V = g_hostAgentScope_size;
  int I = g_hostAgentInVar_size;
  int D = gh_domain_size;
  int ROWS = std::pow((double)D, (double)I);

  for (int v = 0; v < ROWS; v++ ) 
  {
    printf ("GDsample(B): %d:  ", v);
    for (int i = 0; i < V; i++) 
    {
      int d_idx = gh_best_outvals_utuples[ v * (V+1) + i];
      printf ("%d ", g_hostAgentVarInfo[ i ].domain[ d_idx ] );
      }
    int val = gh_best_outvals_utuples[ v * (V+1) + V ];
      printf(" | %d \n", val);
    }
}
