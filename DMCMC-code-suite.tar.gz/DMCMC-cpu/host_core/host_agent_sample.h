#ifndef HOST_AGENT_SAMPLE_H
#define HOST_AGENT_SAMPLE_H

#include "globals.h"

namespace host_agent
{

  void sample( int X_size, int I_size, int D_size,  int nIterations, 
	       int nSeeds, long int* h_best_samples, int Aid, std::string alg );

  bool gibbs( long int* best_sample, int seed, int nSeeds, long int row, long int nSamples );
  bool block_metropolis_hasting( long int* best_sample, int seed, int nSeeds, long int row, long int nSamples, long int& prev_cost, long int t );

  bool metropolis_hasting( long int* best_sample, int seed, int nSeeds, long int row, long int nSamples, long int& prev_cost, long int t );

  long int random_walk( int seed, long int row, long int nSamples );

};

#endif
