#include "host_agent_init.h"
#include "globals.h"
#include "host_globals.h"
#include "permutations.h"
#include "agent.h"
#include "constraint.h"
#include "relation.h"
#include "var_int.h"
#include "domain.h"

//#define DBG

using std::vector;
using std::map;
using std::string;

bool _allScopeCovered(Constraint*, int);
var_int* _lookupVar(vector<var_int*>, int);

void host_agent::dumpAgent( int i )
{
  printf(" A_%d.dev=%d\n", i, cudaAgent.device_id);
  printf(" A_%d.L=%d\n", i, cudaAgent.local_vars_size);
  printf(" A_%d.I=%d\n", i, cudaAgent.in_vars_size);
  printf(" A_%d.Nsample=%ld\n", i, cudaAgent.n_samples);
  printf(" A_%d.Nseeds=%d\n", i, cudaAgent.n_seeds);
  printf(" A_%d.CA=%d\n", i, cudaAgent.n_constr);
}

/* To be called only once for all Agents */
void host_agent::initAgent
( int dev_id, bool max, int dom_size, int l_size, int i_size, int n_seeds )
{
  int ot = max ? _maximize : _minimize ;
  g_host_opt = ot;
  g_host_dom_size = dom_size;

  cudaAgent.device_id = dev_id;
  cudaAgent.opt_type = ot;
  cudaAgent.dom_size = dom_size;
  cudaAgent.local_vars_size = l_size;
  cudaAgent.in_vars_size = i_size;
  cudaAgent.n_seeds = n_seeds;
  
  cudaAgent.samples = NULL;
  cudaAgent.n_samples = -1;
  cudaAgent.constr = NULL;
  cudaAgent.n_constr = -1;
    //cudaAgent.constr_scope = NULL;
  // cudaAgent.constr_utils = NULL;   
}//-


void host_agent::initGibbsSamples( int V, int I, int D, int nSeeds)
{
  Permutations perm( D, I );
  long int ntuples = perm.size();
  long int TABLE_size = ntuples * ( V + 1 );

  cudaAgent.samples = new long int[nSeeds * TABLE_size];
  cudaAgent.n_seeds = nSeeds;
  cudaAgent.n_samples = ntuples;
  long int def_cost = (g_host_opt == _minimize) ? INFTY : -INFTY;
 
  for( int s = 0; s < nSeeds; s++ )
  {
    long int SEED = s * TABLE_size;
    for( long int k = 0; k < ntuples; k++ )
    {
      long int SAMPLE = SEED + (k * (V + 1));
      memcpy(&cudaAgent.samples[SAMPLE],
	     &perm.get_permutations()[k*I],I*sizeof( long int));
      memset(&cudaAgent.samples[SAMPLE+I],-1,(V-I+1)*sizeof(long int));
      /* Int Cost */
      cudaAgent.samples[SAMPLE+V] = def_cost;
    }
  }
}//-



void host_agent::initConstraints( vector<var_int*> scope, int A_id )
{ 
  int X = scope.size();
  int D = g_host_dom_size;
  if( !g_host_constr_size) g_host_constr_size = new int[ g_agents.size() ];

  map< string, Constraint* >::iterator c_it =  g_constraints.begin();
  int counter = 0;
  for ( ; c_it != g_constraints.end(); ++c_it )
  {
    Constraint *C = c_it->second;
    int cid = C->get_id();
    if ( !_allScopeCovered( C, A_id ) ) continue;
    counter ++;
  }//-
  cudaAgent.n_constr         = counter;
  g_host_constr_size[ A_id ] = counter;

  assert(counter > 0);

  cudaAgent.constr = new g_AgentDS_Constr[ counter ];

  c_it = g_constraints.begin();
  int curr_constr = 0;
  
  for ( ; c_it != g_constraints.end(); ++c_it )
  {
    Constraint *C = c_it->second;
    int cid = C->get_id();
    int C_arity = C->get_arity();
    Relation *R = C->ref_relation();

    if ( !_allScopeCovered( C, A_id ) ) continue;

    // cout << "importing Rel " << curr_constr << " / "
    // 	 << cudaAgent.n_constr << " arity " << C_arity << endl;

    int *tuple = new int[ C_arity ];
    int *tuple_dlb = new int[ C_arity ];
    
    long int util_size = (C_arity <= 3) ? 
      std::pow(D, (double)C_arity)
      : R->sizeof_costs();
    size_t size3D = D*D*D;
    
    cudaAgent.constr[ curr_constr ].arity = C_arity;
    cudaAgent.constr[ curr_constr ].scope = new int[ C_arity ];
    cudaAgent.constr[ curr_constr ].utils = new long int[ util_size ];
    cudaAgent.constr[ curr_constr ].ss_idx3D = NULL;
    cudaAgent.constr[ curr_constr ].tuples   = NULL;
    if (C_arity > 3) { // allocate space only if arity > 3
      cudaAgent.constr[ curr_constr ].ss_idx3D = new long int[ 2*size3D + D ];
      cudaAgent.constr[ curr_constr ].tuples   = new int[ R->sizeof_tuples() ];
    }
    cudaAgent.constr[ curr_constr ].def_cost = R->get_def_cost();

    /* Popolate constraint scope with variable ids in the same order
     as the one held by the agent */ 
    for( int ci = 0; ci < C_arity; ci++ )
    {
      int xi = C->ref_scope( ci )->get_id();
      tuple_dlb[ ci ] = _lookupVar( scope, xi )->domain->get_min();
      
      for( int si = 0; si < scope.size(); si++ )
      {
	if( C->ref_scope(ci) == scope[ si ] ) {
	  cudaAgent.constr[ curr_constr ].scope[ ci ] = si;
	}
      }
    }

    // IMPORTANT: We assume that the element tuples are all ordered.
    /* Set def. cost. */
    if( C_arity <= 3 ) 
    {
      for( int i=0; i < util_size; i++ ) {
	cudaAgent.constr[curr_constr].utils[i] = R->get_def_cost();
      }
      for( int t = 0; t < R->sizeof_costs(); t++ ) {
	long int cost = R->get_cost( R->get_tuple( t ) );
	for(int i=0; i<C_arity; i++)
	  tuple[i] = R->get_tuple(t)[i] - tuple_dlb[i];
	cudaAgent.constr[curr_constr].utils[ 
             g_hash_util( D, C_arity, tuple ) ] = cost;
      }
    }
    else { // arity > 3
      for( int i=0; i < 2*size3D; i++ ) {
      	cudaAgent.constr[curr_constr].ss_idx3D[ i ] = -1;
      }

      int x_prev = -1; int y_prev = -1; int z_prev = -1;
      for( int t = 0; t < R->sizeof_costs(); t++ ) 
      {
	long int cost = R->get_cost( R->get_tuple( t ) );
	cudaAgent.constr[curr_constr].utils[ t ] = cost;

	// for now save all, but we can avoid saving the first
	// two dimensions

	for(int i=0; i<C_arity; i++)
	  cudaAgent.constr[ curr_constr ].tuples[ t*C_arity + i ]
	    = R->get_tuple(t)[i] - tuple_dlb[i];

	int x = R->get_tuple(t)[0] - tuple_dlb[0];
	int y = R->get_tuple(t)[1] - tuple_dlb[1];
	int z = R->get_tuple(t)[2] - tuple_dlb[2];

	// store start index for tuple starting by x and y
	if( x != x_prev || y != y_prev || z != z_prev )
	{
	  // x,y start
	  cudaAgent.constr[curr_constr].ss_idx3D[ 2*x*D*D + 2*y*D + 2*z ] = t; //start
	  cudaAgent.constr[curr_constr].ss_idx3D[ 2*x*D*D + 2*y*D + 2*z+1 ] = 2*D*D*D - 1; // end of the array - just in case...
	  if( !(x_prev == -1 && y_prev == -1 && z_prev == -1) ) // not first
	  { // previous stop
	    cudaAgent.constr[curr_constr].ss_idx3D
	      [ 2*x_prev*D*D + 2*y_prev*D + 2*z_prev + 1 ] = t - 1;
	  }
	  x_prev = x; y_prev = y; z_prev = z;
	}
      }

    }
    curr_constr++;
    delete[] tuple;
    delete[] tuple_dlb;
  }

}//-



// check constr scope contains all and only variables within current agent
bool _allScopeCovered( Constraint* C, int A_id )
{
  for (int i = 0; i < C->get_arity(); i++)
  {
    var_int* v = C->ref_scope( i );
    if ( g_agents[ v->get_owner() ]->get_id() != A_id ) return false;
  }
  return true;
}//-

var_int* _lookupVar( vector<var_int*> vars, int id )
{
  for (int i=0; i<vars.size(); i++)
    if ( vars[ i ]->get_id() == id ) return vars[ i ];
  return NULL;
}

void host_agent::free()
{
  delete[] cudaAgent.samples;
  for( int i = 0; i < cudaAgent.n_constr; i++)
  {
    // cout << "freeing constr[ " << i << "]\n";
    delete[] cudaAgent.constr[ i ].scope;
    delete[] cudaAgent.constr[ i ].utils;
    if( cudaAgent.constr[ i ].arity > 3 )
      delete[] cudaAgent.constr[ i ].ss_idx3D;
    if( cudaAgent.constr[ i ].arity > 3 )
      delete[] cudaAgent.constr[ i ].tuples;
  }
 
    delete[] cudaAgent.constr; 

}
