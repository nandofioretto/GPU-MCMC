#ifndef HOST_GLOBALS_H
#define HOST_GLOBALS_H

#include "globals.h"

#define _minimize 0
#define _maximize 1

/* Structures Common to All Agents */
extern int g_host_opt;
extern int g_host_dom_size;
extern int* g_host_constr_size; // Same size as n_cudaAgents

struct g_AgentDS_Constr
{
  int arity;
  int* scope;
  long int* utils;
  long int def_cost;

  long int* ss_idx3D; // start and stop indexes for 
  // combinations of values <a,b,....> ---> <a,c,....>
  int* tuples;

};

/* Local Structures (Agent) */
struct g_AgentDS 
{
  int device_id;
  int opt_type;
  int dom_size;
  int local_vars_size;
  int in_vars_size;
  int n_seeds;
  long int* samples;
  long int n_samples;
  g_AgentDS_Constr* constr;
  int n_constr;
  //  int* constr_scope; // arity + scope
  //  int* constr_utils; // n-ary matrix
};

extern g_AgentDS cudaAgent;
extern size_t g_global_memory_allocated;

size_t g_hash_util( int d, int a, int T[] );
size_t g_hash_util( int d, int a, int  T );

#endif
