#include "globals.h"
#include "host_globals.h"
#include "host_agent_sample.h"

#include <math.h>
#include <time.h>

using namespace std;

//#define DBG

void __dump_samples__ (void);
bool is_better( long int cost_a, long int cost_b );

bool __is_var_in_constr__ (int, int);
long int __get_util__ (int, long int*);
long int __get_util__ (int, long int*, int, int);
int *__tuple; // tmp variable used in __get_util__

// size_t g_accept = 0;
// size_t g_rejects = 0;

// ignore scope and in_vars at this stage [but we need to check 
// whether the scope and inputs are always the same]
void host_agent::sample
( int X_size, int I_size, int D_size, int nIterations, int nSeeds, long int* h_best_samples, int Aid, string alg )
{
  __tuple = new int[ X_size ];
  
  /* samples is the number of possible tuples assigned to the InputVars */
  long int samples  = pow( (double)D_size, (double)I_size );
  long int *best_sample = new long int[ X_size - I_size + 1];
  double avg_iter = 0;
  /* Init The Random value assignment for all the variables in V \ I */
  for (int s = 0; s < nSeeds; s++ )
  {
    long int SEED = s * samples*(X_size + 1);
    for( long int row = 0; row < samples; row++)
    {
      long int SAMPLE = row * (X_size+1);
      long int Sidx_COST = SEED+SAMPLE+X_size;
      long int Bidx_COST = X_size - I_size;
	
       // Random Initial configuration
      for ( int x = I_size; x < X_size; x++ ) 
      {
      	cudaAgent.samples[ SEED + SAMPLE + x ] = (int)(rand() % D_size); 
      }
      best_sample[ Bidx_COST ] = cudaAgent.samples[ Sidx_COST ];
      long int curr_cost = best_sample[ Bidx_COST ]; // prev_cost in GPU version
      // Sampling distrib


      size_t cc =0;

      while ( abs( random_walk( s, row, samples ) ) == INFTY && cc++ < 10000 ) ;
      if( cc <= 10000 )
      	{  for( int i=I_size; i<X_size; i++) 
      	    best_sample[ i-I_size ] = cudaAgent.samples[SEED+SAMPLE+i];
      	  best_sample[ Bidx_COST ] = cudaAgent.samples[SEED+SAMPLE+X_size];
      	}

      long int t = 0;
      for(t = 0; t < nIterations; t++ )
      {
	if( alg.compare("gi") == 0 )
	{
	  /*if (*/ gibbs( best_sample, s, nSeeds, row, samples ) /*) break*/; // converged
	}
	else if( alg.compare("mh") == 0 )
	{ 
	  /*if(*/ metropolis_hasting( best_sample, s, nSeeds, row, samples, curr_cost, t) /*) break*/;
	}
	else if( alg.compare("bmh") == 0 )
	{
	  /*if(*/ block_metropolis_hasting( best_sample, s, nSeeds, row, samples, curr_cost, t) /*) break*/;
	}
	else {cout << "No alg found"; exit(-2); }
	// __dump_samples__ ();
	// getchar();
	//if( g_stats->timeout( Aid ) ) break;
      }
      avg_iter += t;
      
      if( is_better( best_sample[ Bidx_COST ],  cudaAgent.samples[ Sidx_COST ] ) )
      {
	memcpy(&cudaAgent.samples[ SEED + SAMPLE + I_size ],
	       best_sample, (X_size-I_size + 1) * sizeof( long int) );
      }
    }//- rows
  }//- seeds
  delete[] best_sample;

#ifdef DBG
  // if( alg.compare("mh") == 0 )
  //   cout << "accept/reject ratio: " << 
  //     (double)(g_accept / (double) g_rejects ) << endl;
  cout << "A" << Aid << " avg iter: " << avg_iter/(double)(samples*nSeeds) << endl;
#endif

  // Copy best samples back 
  int opt_cond = cudaAgent.opt_type;
  long int best = opt_cond==_maximize ? -INFTY : INFTY;
  for( long int row = 0; row < samples; row++)
  {
    long int SAMPLE = row * (X_size+1);
    long int BEST_SAMPLE = -1;
    for (int s = 0; s < nSeeds; s++ )
    {
      long int SEED = s * samples * ( X_size + 1 );
      long int Sidx_COST = SEED+SAMPLE+X_size;
      if( BEST_SAMPLE == -1 ) BEST_SAMPLE = SEED+SAMPLE; // assign first in case no better sample is found

      /* Check best */
      if( is_better( cudaAgent.samples[ Sidx_COST ], best ) )
      {
	best = cudaAgent.samples[ Sidx_COST ];
	BEST_SAMPLE = SEED + SAMPLE;
      }
    }
    assert(BEST_SAMPLE >= 0);
    memcpy( &h_best_samples[ SAMPLE ], 
	    &cudaAgent.samples[ BEST_SAMPLE ], ( X_size + 1 ) * sizeof(long int) );

  }
  delete[] __tuple;
  
}//-


bool host_agent::gibbs
( long int* best_sample, int seed, int nSeeds, long int row, long int nSamples )
{

  int D = cudaAgent.dom_size;
  int X = cudaAgent.local_vars_size;
  int I = cudaAgent.in_vars_size;
  int C_A = cudaAgent.n_constr;
  int opt_cond = cudaAgent.opt_type;

  long int SEED_S = seed * nSamples*(X+1);
  long int SAMPLE = row*(X+1);
  long int *curr_sample = &cudaAgent.samples[ SEED_S + SAMPLE ];

  double *P = new double[ D ];
  bool converged = true;

  for (int x_sample = I; x_sample < X; x_sample++)
  {

    double _Zinv = 0.0;
    ///
    // Normalization Constant
    ///
    for (int d = 0; d < D; d++ )
    {
      long int u = 0;
      long int i_acc = 0;
      for(int c = 0; c < C_A; c++ )
	{
	  if( __is_var_in_constr__ ( x_sample, c ) )
	    { 
	      u = __get_util__( c, curr_sample, x_sample, d );
	      if ( u == INFTY || u == -INFTY) { i_acc = 0; goto compP; }
	      else i_acc += u;
	    }
	}
    compP:
      P[ d ] = (i_acc > 0 ) ? exp( (double)i_acc ) : 1.0;//0.0;
      _Zinv += P[ d ];
    }
    //if(_Zinv == 0.0 ) { /*cout << "error Zinv = 0 ;";*/  continue; }
    _Zinv = (1 / _Zinv );
  
    ///
    // Probabilites and update current sample
    ///
    for (int d = 0; d < D; d++ ) { P[ d ] *= _Zinv; }
    /* Choose a value for x -- based on prob. P */
    double x_rand_choice = ( ( double )( rand() % 1000000 ) / (double)1000000); 
    double Pacc = 0; int d = -1;
    do {
      Pacc += P[ ++d ];
    } while ( x_rand_choice >= Pacc && d < (D-1) ); 
    
    /* and save it in the output state */
    int old_x = curr_sample[ x_sample ];
    curr_sample[ x_sample ] = (d < D) ? d : (D-1);
    long int i_acc = 0, u = 0;
    // check state has changed
    if( old_x != curr_sample[ x_sample ] )
      {
	converged = false;
      }
	/* Scan each constraint involved in A (i.e., which has all the variables
	   in its scope in A) */
	for(int c = 0; c < C_A; c++ )
	  {
	    u = __get_util__( c, curr_sample );
	    if ( u == INFTY || u == -INFTY) { i_acc = u; break; }
	    i_acc += u;
	  }
	curr_sample[ X ] = i_acc;
	
	///
	// Save Best Sample
	///
	if( (opt_cond==_maximize && i_acc > best_sample[ X-I ] ) ||
	    (opt_cond==_minimize && i_acc < best_sample[ X-I ] ) )
	  {
	    for (int c = I; c < X; c++)
	      best_sample[ c - I ] = curr_sample[ c ];
	    best_sample[ X-I ] = i_acc;
	  }
	// } // check state is changed
  }
  delete[] P;
  return converged;

}//-


double __rnd_normal( double mu, double sigma )
{
  static double n2 = 0.0;
  static int n2_cached = 0;
  if( !n2_cached ) {
    double x,y,r;
    do{
      x = 2.0*rand()/RAND_MAX - 1;
      y = 2.0*rand()/RAND_MAX - 1;
      r = x*x + y*y;
    } while(r == 0.0 || r > 1.0);
    {
      double d = sqrt( -2.0*log(r)/r);
      double n1=x*d;
      n2=y*d;
      double result = n1*sigma + mu;
      n2_cached = 1;
      return result;
    }
  } else {
    n2_cached = 0;
    return n2*sigma + mu;
  }
}//-


// metropolis hasting
bool host_agent::metropolis_hasting
( long int* best_sample, int seed, int nSeeds, long int row, long int nSamples, 
  long int& prev_cost, long int t )
{
  int D = cudaAgent.dom_size;
  int X = cudaAgent.local_vars_size;
  int I = cudaAgent.in_vars_size;
  int C_A = cudaAgent.n_constr;
  int opt_cond = cudaAgent.opt_type;

  long int SEED_S = seed * nSamples*(X+1);
  long int SAMPLE = row*(X+1);
  long int *curr_sample = &cudaAgent.samples[ SEED_S + SAMPLE ];
  long int curr_cost = 0;
  
  double *P = new double[ D ];
  long int *prev_sample = new long int[ X ];
  bool converged = true;

  for (int x_sample = I; x_sample < X; x_sample++)
  {
    prev_sample[ x_sample ] = curr_sample[ x_sample ];
    double sd = sqrt(D);
    int v = (int)__rnd_normal( prev_sample[ x_sample ], sd );

    curr_sample[ x_sample ] = 
      //(int)(rand() % D); 
    min( max(0, v), D-1);
    if( curr_sample[x_sample] != prev_sample[x_sample]) converged = false;
  }

  // if( converged ) return converged;
  
  /* ==========================================================
     Compute JOINT UTILITY
     ========================================================== */
  long int i_acc = 0, u = 0;
  curr_cost = 0;
  /* Scan each constraint involved in A (i.e., which has all the variables
     in its scope in A) */
  for(int c = 0; c < C_A; c++ )
    {
      u = __get_util__( c, curr_sample );
      if ( u == INFTY || u == -INFTY) { i_acc = u; break; }
      i_acc += u;
    }
  curr_cost = i_acc;
  
  double rnd = ( ( double )( rand() % 1000000 ) / (double)1000000); 
  
  //Accept/Reject 
  bool accept = false;
  if( curr_cost == INFTY || curr_cost == -INFTY ) {accept = false; }
  else {
    if(opt_cond==_maximize)
      {
	if(curr_cost > prev_cost) accept = true; // accept if improves solution
	else if( rnd < (curr_cost/(double)prev_cost) ) accept = true; // accpet/reject case
	else accept = false; // reject
      }
    else
      {
	if(curr_cost < prev_cost) accept = true; // accept if improves solution
	else if( rnd < (prev_cost/(double)curr_cost) ) accept = true; // accpet/reject case
	else accept = true; // reject
      }
  }
  //if( t > 100 )
  if(accept) 
  { 
    //g_accept++;
    prev_cost = curr_cost;
    /* ==========================================================
       Save BEST STOLUTION
       ========================================================== */
    if( (opt_cond==_maximize && curr_cost > best_sample[ X-I ] ) ||
	(opt_cond==_minimize && curr_cost < best_sample[ X-I ] ) )
      {
	for (int c = I; c < X; c++)
	  best_sample[ c - I ] = curr_sample[ c ];
	best_sample[ X-I ] = curr_cost;
      }
  }
  else 
    {
      //g_rejects++;
      for( int i=I; i<X; i++) 
	curr_sample[ i ] = prev_sample[ i ];
    }
  
  delete[] P;
  delete[] prev_sample;

  return converged;

}//-



// single block metropolis hasting
bool host_agent::block_metropolis_hasting
( long int* best_sample, int seed, int nSeeds, long int row, long int nSamples, 
  long int& prev_cost, long int t )
{

  int D = cudaAgent.dom_size;
  int X = cudaAgent.local_vars_size;
  int I = cudaAgent.in_vars_size;
  int C_A = cudaAgent.n_constr;
  int opt_cond = cudaAgent.opt_type;

  long int SEED_S = seed * nSamples*(X+1);
  long int SAMPLE = row*(X+1);
  long int *curr_sample = &cudaAgent.samples[ SEED_S + SAMPLE ];
  long int curr_cost = 0;

  double *P = new double[ D ];
  bool converged = true;

  for (int x_sample = I; x_sample < X; x_sample++)
  {
    long int prev_val = curr_sample[ x_sample ];
    int v = //(int)__rnd_normal( prev_val, sqrt(D) );
      (int)(rand() % D); 

    curr_sample[ x_sample ] = 
      min( max(0, v), D-1);
    //(int)(rand() % D); 
    if( prev_val != curr_sample[x_sample] ) converged = true;

    //if( prev_val == curr_sample[x_sample] ) continue;

    /* ==========================================================
       Compute JOINT UTILITY
       ========================================================== */
    long int i_acc = 0, u = 0;
    curr_cost = 0;
    /* Scan each constraint involved in A (i.e., which has all the variables
       in its scope in A) */
    for(int c = 0; c < C_A; c++ )
    {
      u = __get_util__( c, curr_sample );
      if ( u == INFTY || u == -INFTY) { i_acc = u; break; }
      i_acc += u;
    }
    curr_cost = i_acc;
    
    double rnd = ( ( double )( rand() % 1000000 ) / (double)1000000); 

    //Accept/Reject 
    bool accept = false;

    if( curr_cost == INFTY || curr_cost == -INFTY ) {accept = false; }
    else {
      if(opt_cond==_maximize)
      {
	if(curr_cost > prev_cost) accept = true; // accept if improves solution
	else if( rnd < (curr_cost/(double)prev_cost) ) accept = true; // accpet/reject case
	else accept = false;
      }
      else
      {
	if(curr_cost < prev_cost) accept = true; // accept if improves solution
	else if( rnd < (curr_cost/(double)prev_cost) ) accept = true; // accpet/reject case
	else accept = false;
      }

      if(accept)
	{
	  prev_cost = curr_cost;
	  /* ==========================================================
	     Save BEST STOLUTION
	     ========================================================== */
	  if( (opt_cond==_maximize && curr_cost > best_sample[ X-I ] ) ||
	      (opt_cond==_minimize && curr_cost < best_sample[ X-I ] ) )
	    {
	      for (int c = I; c < X; c++)
		best_sample[ c - I ] = curr_sample[ c ];
	      best_sample[ X-I ] = curr_cost;
	    }
	}
      else // reject
	{
	  curr_sample[ x_sample ] = prev_val;
	}
    }
    

  }
  delete[] P;
  return converged;

}//-

// random walk
long int host_agent::random_walk( int seed,  long int row, long int nSamples )
{
  
  int D = cudaAgent.dom_size;
  int X = cudaAgent.local_vars_size;
  int I = cudaAgent.in_vars_size;
  int C_A = cudaAgent.n_constr;
  long int SEED_S = seed * nSamples*(X+1);
  long int SAMPLE = row*(X+1);
  long int *curr_sample = &cudaAgent.samples[ SEED_S + SAMPLE ];
 
  for (int x_sample = I; x_sample < X; x_sample++)
  {
    curr_sample[ x_sample ] = (int)(rand() % D); 
  }

  /* ==========================================================
     Compute JOINT UTILITY
     ========================================================== */
  long int i_acc = 0, u = 0;
  /* Scan each constraint involved in A (i.e., which has all the variables
     in its scope in A) */
  for(int c = 0; c < C_A; c++ )
    {
      u = __get_util__( c, curr_sample );
      if ( u == INFTY || u == -INFTY) { i_acc = u; break; }
      i_acc += u;
    }
  curr_sample[ X ] = i_acc;
  return i_acc;
  
}//-



bool __is_var_in_constr__ ( int var, int cid )
{
  int *scope = cudaAgent.constr[ cid ].scope;
  for( int i=0; i<cudaAgent.constr[ cid ].arity; i++)
    if( var == scope[i] ) return true;
  return false;
}//-


// there is something wrong here! CHECK
long int __get_util__ (int cid, long int *sample, int var_sobst, int val_sobst )
{
  // only extract subsequence relevant to this constraint
  int *scope = cudaAgent.constr[ cid ].scope;
  int a = cudaAgent.constr[ cid ].arity;
  long int cost = cudaAgent.constr[ cid ].def_cost;
  int D = cudaAgent.dom_size;

  if( a <= 3)
  {
    for( int i=0; i<a; i++)
    {
      __tuple[i] = scope[i] == var_sobst ? val_sobst : sample[scope[i]];
    }
    cost = cudaAgent.constr[cid].utils[ g_hash_util( cudaAgent.dom_size, a, __tuple ) ];
  }
  else 
  {
    // - get the first two numbers in the sample,
    int x = scope[0] == var_sobst ? val_sobst : sample[ scope[0] ];
    int y = scope[1] == var_sobst ? val_sobst : sample[ scope[1] ];
    int z = scope[2] == var_sobst ? val_sobst : sample[ scope[2] ];
    // - retrieve start and stop index from (to) where to check
    long int start = cudaAgent.constr[cid].ss_idx3D[ 2*x*D*D + 2*y*D + 2*z ];
    if( start == -1 ) goto ret_cost;
    long int stop  = cudaAgent.constr[cid].ss_idx3D[ 2*x*D*D + 2*y*D + 2*z+1 ];
    // - check in the array of tuplse starting from such index
    for( long int i = start; i <= stop; i++)
    {
      for(int t=3; t<a; t++)
      {
	int check = scope[t] == var_sobst ? val_sobst : sample[ scope[t] ];
	if( cudaAgent.constr[cid].tuples[ i*a + t ] != check )
	  break;
	cost = cudaAgent.constr[cid].utils[ i ];
	goto ret_cost;
      }
    }
    // - return value if found or default if not
  }
 ret_cost:
  return cost;

}//-

long int __get_util__ (int cid, long int *sample )
{
  // only extract subsequence relevant to this constraint
  int *scope = cudaAgent.constr[ cid ].scope;
  int a = cudaAgent.constr[ cid ].arity;
  long int cost = cudaAgent.constr[ cid ].def_cost;
  int D = cudaAgent.dom_size;
  if( a <= 3)
    {  for( int i=0; i<a; i++)
	{
	  __tuple[i] = sample[scope[i]];
	}
      cost = cudaAgent.constr[cid].utils[ g_hash_util( cudaAgent.dom_size, a, __tuple ) ];
    }
  else
    {
      // - get the first two numbers in the sample,
      int x = sample[scope[0]];
      int y = sample[scope[1]];
      int z = sample[scope[2]];
      // - retrieve start and stop index from (to) where to check
      long int start = cudaAgent.constr[cid].ss_idx3D[ 2*x*D*D + 2*y*D + 2*z ];
      if( start == -1 ) goto ret_cost;
      long int stop  = cudaAgent.constr[cid].ss_idx3D[ 2*x*D*D + 2*y*D + 2*z+1 ];
      // - check in the array of tuplse starting from such index
      for( long int i = start; i <= stop; i++)
      {
	for(int t=3; t<a; t++)
	  {
	    if( cudaAgent.constr[cid].tuples[ i*a + t ] != sample[ scope[t] ] )
	      break;
	    cost = cudaAgent.constr[cid].utils[ i ];
	    goto ret_cost;
	  }
      }
      // - return value if found or default if not
    }
 ret_cost:
  return cost;
}//-



void __dump_samples__ ()
{
  int D = cudaAgent.dom_size;
  int X = cudaAgent.local_vars_size;
  int I = cudaAgent.in_vars_size;
  int nSamples = cudaAgent.n_samples;
  int nSeeds   = cudaAgent.n_seeds;

  for( int s = 0; s < nSeeds; s++)
  {
    long int SEED = s * nSamples*(X+1);
    printf("*** SEED %d ***\n", s );
    for (int r = 0; r < nSamples; r++ ) 
    {
      long int SAMPLE = r*(X+1);
      printf ("GDsample %d: <", r);
      for (int i = 0; i < X; i++) 
      {
	printf("%ld ", cudaAgent.samples[ SEED + SAMPLE + i ] );
      }
      printf("> %ld \n", cudaAgent.samples[ SEED + SAMPLE + X ] );
    }
  }
}


bool is_better( long int cost_a, long int cost_b )
{
  int opt_cond = cudaAgent.opt_type;
  if( (opt_cond==_maximize && cost_a > cost_b) ||
      (opt_cond==_minimize && cost_a < cost_b ) )
    return true;
  return false;
}

