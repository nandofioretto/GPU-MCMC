#include "agent.h"

#include "host_agent_init.h"
#include "host_agent_sample.h"
using namespace host_agent;

#include "domain.h"
#include "var_int.h"
#include "constraint.h"
#include "relation.h"
#include "permutations.h"
#include "message.h"
#include <rapidxml.hpp>
using namespace rapidxml;
using namespace std;


//#define DBG
//#define SINGLE_AGENT_DBG
Agent::Agent( xml_node<>* agent )
  : _name( "" ),
    _device( 0 ),
    _best_samples( NULL ),
    _n_best_samples( 0 ),
    _numof_received_VALUE_msgs( 0 ),
    _numof_received_UTIL_msgs( 0 )
{
  static size_t _g_AGENTS_COUNTER = 0;
  _id = _g_AGENTS_COUNTER++;
  _name  = agent->first_attribute("name")->value();
  g_agents[ _name ] = this;
}//-

Agent::~Agent()
{ 
  if (_best_samples) free( _best_samples );
}//-

bool orderVarDes (var_int* LHS, var_int* RHS) 
{
  return ( LHS->get_id() < RHS->get_id() );
}//-

string Agent::get_name()
{
  return _name;
}//-

size_t Agent::get_id()
{
  return _id;
}//-

void Agent::free_global_DS()
{
  host_agent::free();
}//-

void Agent::set_opt( bool maximize )
{
  _optMax = maximize;
}//-

bool Agent::get_opt( )
{
  return _optMax;
}//-

void Agent::add_variable( var_int* v )
{
  if ( find( scope.begin(), scope.end(), v) == scope.end() )
    scope.push_back( v );
}//-

void Agent::add_variables( )
{
  /* Retrieve input variables */
  vector< var_int* > _invar;

  for( int i = 0; i < scope.size(); i++)
  {
    var_int *vi = scope[ i ];
    map< string, Constraint* >::iterator c_it = g_constraints.begin();
    bool pushed = false;
    for ( ; c_it != g_constraints.end(); ++ c_it )
    {
      Constraint* Ci = c_it->second;
      if( Ci->has_in_scope( vi ) )
      {
	for ( int j = 0; j < Ci->get_arity(); j++ )
	{
	  var_int *vj = Ci->ref_scope( j );
	  if ( vi->get_id() != vj->get_id() && ! this->has_in_scope( vj ) )
	  {
	    _invar.push_back( vi );
	    pushed = true;
	    break;
	  }
	}
      }
      if (pushed) break;
    }
  }
  
  sort( _invar.begin(), _invar.end(), orderVarDes );
  vector< var_int* >::iterator it;
  
  // Reorder scope variables
  for( int i = _invar.size()-1; i >= 0; i--)
  {
    it = find( scope.begin(), scope.end(), _invar[ i ] );
    scope.erase( it );
    scope.insert( scope.begin(), _invar[ i ] );
  }

  in_vars_size = (int)_invar.size();
}//-

bool Agent::has_in_scope( var_int* v )
{
  for( int i = 0; i < scope.size(); i++ )
    if( scope[ i ]->get_id() == v->get_id() )
      return true;
  return false;
}//-

int Agent::scope_size()
{
  return scope.size();
}//-

int Agent::invar_size()
{
  return in_vars_size;
}//-

var_int* Agent::get_var( int i )
{
  return scope[ i ];
}//-

vector< var_int* > Agent::get_input_vars( )
{
  vector< var_int* > res( in_vars_size );
  for( int i = 0; i < in_vars_size; i++)
    res[ i ] = scope[ i ];
  return res;
}//-

vector< var_int* > Agent::get_input_vars_in( vector< Constraint* > con )
{
  vector< var_int* > res;
  for(int c=0; c<con.size(); c++) {
    for(int i=0; i<in_vars_size; i++) {
      if(con[c]->has_in_scope(scope[i]) &&
    	 find(res.begin(),res.end(),scope[i]) == res.end() )
    	res.push_back(scope[i]);
    }
  }
  return res;
}//-

/*
 * NOTE: It is important to order the scope variables so that 
 * InitVariables are listed first and SamplingVariables are listed
 * after. 
 * For each of the two sets the listing order is ascending and based
 * on their IDs.
 */
void Agent::init( int dev, int nseeds )
{
  _device = dev;
  _nseeds = nseeds;
  int d_size = scope[0]->domain->size();
  
  /* Init Scope variables: first in_vars_size are the input vars while */
  int scope_ids[scope.size()];
  for (int i=0; i < scope.size(); i++) 
    scope_ids[ i ] = scope[ i ]->get_id();
  long int nsamples = std::pow((double)d_size, (double)in_vars_size);
 
  _best_samples = (long int*)malloc( nsamples*(scope.size()+1) * sizeof(long int) );
  _n_best_samples = nsamples;

  /* Init Agent DS */
  initAgent( dev, _optMax, d_size, scope.size(), in_vars_size, nseeds);
  /* Init Out Tuple variables + utility */
  initGibbsSamples( scope.size(), in_vars_size , d_size, nseeds );
  /* Init constraint Support: Constraint Info  */
  initConstraints( scope, _id );
}//-

//
// Sampling Support
//
void Agent::sampling( int _T, int _skip, string alg )
{
  srand (time(NULL));
  int dom_size = scope[ 0 ]->domain->size();
  host_agent::sample( scope.size(), in_vars_size, dom_size, 
		      _T,  _nseeds, _best_samples, _id, alg );
  
}//-

long int Agent::get_best_sample_util( long int i )
{
  return _best_samples[ i* (scope.size()+1) + (scope.size()) ];
}


//
// Pseudo-Tree construction Support
//

bool Agent::is_root()
{
  return ( _parent.first == NULL );
}

bool Agent::is_leaf()
{
  return _children.empty();
}

void Agent::set_parent( Agent* p, vector< Constraint* > C )
{
  _parent = make_pair( p, C );
}

void Agent::add_child( Agent* c, vector< Constraint* > C )
{
  _children.push_back( make_pair(c, C) );
  _received_VALUE_msgs.push_back( NULL );
}

// only direct ancestors - i.e. neighbours 
void Agent::add_ancestor( Agent* a, vector< Constraint* > C )
{
  _ancestors.push_back( make_pair(a, C) );
}

int Agent::n_ancestors()
{
  return _ancestors.size();
}

Agent* Agent::get_ancestor( int i )
{
  return _ancestors[ i ].first;
}

Agent* Agent::get_child(int i)
{
  return _children[ i ].first;
}

int Agent::n_children()
{
  return _children.size();
}

Agent* Agent::get_parent()
{
  return _parent.first;
}


//
// Communication Support
//
bool not_in( vector< std::pair< Agent*, vector<Constraint*> > > _children,
	     var_int* v )
{
  for (int i=0; i < _children.size(); i++)
    if (_children[ i ].first->get_name() == v->get_owner()){
      return false;
    }
  return true;
}//-

// vi is ancestor of vj
bool is_ancestor( var_int* vi, var_int* vj )
{
  Agent* Aj = g_agents[ vj->get_owner() ];
  for (int i=0; i < Aj->n_ancestors(); i++)
    if ( Aj->get_ancestor( i )->get_name() == vi->get_owner()){
      return true;
    }
  return false;
}//-

// FILL S and C
// look only at variables in common with this agent input variables
// in this agent ancestors and parent
void Agent::get_separator
( vector<var_int*>& I, vector<var_int*>& S, vector<Constraint*>& C)// WORKS!
{
  for(int i=0; i<in_vars_size; i++)
  {
    I.push_back( scope[ i ] );
  }

  for(int i=0; i<in_vars_size; i++)
  {
    var_int* vi = scope[ i ];
    for( int c = 0; c < vi->numof_constraints(); c++) 
    {
      Constraint* c_vi = vi->get_constraint( c ); 
      int arity = c_vi->get_arity();
      for( int a = 0; a < arity; a++ )
      {
	var_int* vj = c_vi->ref_scope( a );
	if(// not in already 
	   // find(S.begin(), S.end(), vj->get_id() ) == S.end()
	   // && // not children
	   not_in( _children, vj )
	   && // vi is not an ancestor of vj
	   ! is_ancestor (vi, vj )
	   && // not same owner
	   vi->get_owner() != vj->get_owner())
	{
	  if( find( S.begin(), S.end(), vj)==S.end() &&
	      find( I.begin(), I.end(), vj)==I.end() ) S.push_back( vj );
	  if( find( C.begin(), C.end(), c_vi)==C.end()) C.push_back( c_vi );
	}
      }//-arity of c_vi
    }//-constraints involving vi
  }//-in vars (vi)
  sort( S.begin() /*+ in_vars_size*/, S.end() );

}//-


// Create VALUE message and save it to the _VALUE_msg memory area
bool Agent::send_VALUE_msg()
{
  if( _numof_received_VALUE_msgs < n_children() ) {
    return false;
  }
  _VALUE_msg.set_header( this, _parent, _ancestors );
  _VALUE_msg.make( this, _parent, _ancestors );
  return true;
}//-

// Copy value messages from the children in _received_value_msgs
bool Agent::recv_VALUE_msgs()
{
  for( int c = 0; c < n_children(); c++ )
  {
    _received_VALUE_msgs[ c ] =
      _children[ c ].first->get_VALUE_msg( );
    if( _received_VALUE_msgs[ c ] != NULL ) {
      _numof_received_VALUE_msgs ++ ;
    }
  }
  if( _numof_received_VALUE_msgs == n_children() ) 
    return true;
  else return false;
}//-

Message* Agent::get_VALUE_msg()
{
  if( _numof_received_VALUE_msgs < n_children() )
    return NULL;
  return &_VALUE_msg;
}

Message* Agent::get_received_VALUE_msg( long int i )
{
  if( i < _numof_received_VALUE_msgs )
    return _received_VALUE_msgs[ i ];
  return NULL;
}//-

//
// Mischellaneous
//
void Agent::dump_best_samples()
{
  cout << "=== Agent " << _name << " Best samples ===\n";
  for( int i = 0; i < _n_best_samples; i++)
  {
    cout << "[";
    for( int j = 0; j < scope.size(); j++)
    {
      cout << " " << _best_samples[ i*(scope.size()+1) + j ];
      if ( j == (in_vars_size-1) ) cout << "]";
    }
    cout << " | " << _best_samples[i* (scope.size()+1) + (scope.size()) ]
	 << endl; 
  }
  cout << "=== ===================== ===\n";

}//-

void Agent::dump() 
{
  cout << "Agent " << _name << endl;
  cout << "V scope ([";
  for( int i=0; i<scope.size(); i++ )
    {
      cout << scope[i]->get_id();
      if( i==in_vars_size-1) cout<<"]";
      cout << " ";
    }
  cout <<")\n";
  if ( _optMax ) cout << " Maximize\n";
  else cout << "Minimize\n";
  
  for( int in =0; in < _n_best_samples; in ++ ) {
    cout << endl << in << ": ";
    for (int i = 0; i <= scope.size(); i++)
      cout << " " << _best_samples[ in*(scope.size()+1)+i ];
  }
  cout << endl;

  // for (int i = 0; i < scope.size(); i++) scope[i]->dump();
  // std::cout << "V input \n";
  // for (int i = 0; i < in_vars_size; i++) scope[i]->dump();
}
