#ifndef TABLE
#define TABLE

#include "globals.h"
using namespace std;

class Table
{
  vector<int> variables;
  vector<vector<int> > values; // values and utilities  
}

#endif
