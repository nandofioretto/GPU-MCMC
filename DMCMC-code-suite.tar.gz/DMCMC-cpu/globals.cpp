#include "globals.h"
#include "agent.h"
#include "domain.h"
#include "var_int.h"
#include "constraint.h"
#include "relation.h"
#include "statistics.h"

std::map< std::string, Agent* >      g_agents;
std::map< std::string, Domain* >     g_domains;
std::map< std::string, var_int* >    g_variables;
std::map< std::string, Relation* >   g_relations;
std::map< std::string, Constraint* > g_constraints;

// for pseudo-tree construction
std::map<Agent*, std::vector<Agent*> > g_agent_neighbours;

Statistics* g_stats;

int g_solution;
unsigned int g_dom_c;
