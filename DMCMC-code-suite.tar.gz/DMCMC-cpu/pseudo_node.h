#ifndef PSEUDO_NODE_H
#define PSEUDO_NODE_H

#include "globals.h"

class Agent;

class PseudoNode
{
 private:
  Agent* content;
  PseudoNode* parent;
  std::vector< PseudoNode* > children;
  bool locked;

 public:
  PseudoNode( Agent* _content = NULL, PseudoNode* _paernt = NULL );
  PseudoNode( const PseudoNode& other );
  ~PseudoNode();
  PseudoNode& operator= ( const PseudoNode& other );
  
  void insertChild( PseudoNode *child );
  PseudoNode* getParent();
  std::vector< PseudoNode* > getChildren();
  Agent* getContent();

  bool isLeaf() const;
  bool isRoot() const;
  void lock();
  void unlock();
  bool isLocked() const;
  void dump() const;
};//-

#endif
