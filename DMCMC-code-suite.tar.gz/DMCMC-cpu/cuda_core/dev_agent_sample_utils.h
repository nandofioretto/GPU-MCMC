#ifndef _DEV_AGENT_UTILS_H
#define _DEV_AGENT_UTILS_H

#include "dev_globals.h"

void __dumpGdSamples__( int nSeeds, bool best );
void __setPRNGs__( int samples, curandState* devStates, int nSeeds );
void __computeJointUtility__( int nSamples, int nSeeds );
void __getAllSamples__( int *outsample, int nsamples, int X, int nSeeds);

__device__ int __getUtility__( int c, int *curr_sample, int D );
__device__ int __getUtility__( int c, int *curr_sample, int D, int x, int d );

#endif
