#ifndef DEVICE_AGENT_SAMPLE_H
#define DEVICE_AGENT_SAMPLE_H

#include <stdio.h>
#include <string.h>

namespace dev_agent 
{
  void gibbsSampling_1
    ( int X, int I, int D, int nsamples, int nskip, int nseeds, int* h_best_sample);
  void gibbsSampling_1i
    ( int X, int I, int D, int nsamples, int nskip, int nseeds, int* h_best_sample);

  void gibbsSampling_2
    ( int X, int I, int D, int nsamples, int nskip, int nseeds, int* h_best_sample);
  void gibbsSampling_2i
    ( int X, int I, int D, int nsamples, int nskip, int nseeds, int* h_best_sample);

  void gibbsSampling_3
    ( int X, int I, int D, int nsamples, int nskip, int nseeds, int* h_best_sample);
};

#endif
