#ifndef DEVICE_AGENT_INIT_H
#define DEVICE_AGENT_INIT_H

#include "globals.h"

namespace dev_agent
{
  void setDevice( int device=0 );
  void initOpt( bool max );
  void initDomains( int size );
  void initVariableInfo( std::vector< var_int*> scope, int n_invars );
  void freeVariableInfo();
  void initGibbsSamples( int V, int I, int D, int nSeeds );
  void freeGibbsSamples();
  void initConstraintInfo( std::vector<var_int*> scope );
  void freeConstraintInfo();
  void initNormConst( int D_size, int I_size, int nSeeds );
  void freeNormConst();

};

#endif
