#ifndef DEV_GLOBALS_H
#define DEV_GLOBALS_H

/* Common dependencies */
#include <stdlib.h> // for atoi
#include <stdio.h>
#include <sys/time.h>
#include <string.h>
#include <cuda.h>
#include <curand_kernel.h>

/* Tesla C2075 */
#define TOT_GLOBAL_MEM 1341587456
#define TOT_SHARED_MEM 49152  // per block
#define TOT_REGISTERS  32768  // per block
#define MAX_DIM_GRID   65535
#define MAX_DIM_BLOCK  1024
#define WARP_SIZE      32

#define CUDA_CALL(x) do { if((x) != cudaSuccess) {	\
      printf("Error at %s:%d\n",__FILE__,__LINE__);	\
      return EXIT_FAILURE;}} while(0)
#define CUDA_GET_UTILITY(x,y) return gd_utility[ x * gd_domain_size + y ];

#define cudaCheck(ans) { gpuAssert((ans), __FILE__, __LINE__); }
inline void gpuAssert(cudaError_t code, char *file, int line, bool abort=true)
{
  if (code != cudaSuccess) 
  {
    fprintf(stderr,"GPUassert: %s %s %d\n", cudaGetErrorString(code), file, line);
    if (abort) exit(code);
  }
}

#define _minimize 0
#define _maximize 1

extern __device__ int g_devOptimization;
extern int g_hostOptimization;


// CUDA global structures used by an Agent
extern __device__ int  gd_domain_size;
extern            int  gh_domain_size; /* Aux */
extern __device__ int* gd_outvals_utuples; 
extern __device__ int* gd_best_outvals_utuples; 
extern __device__ int  gd_outvals_utuples_size;

/*
 * Each variable held by the current agent has an entry in 
 * this struct. It describes the variable domain and the 
 * constraints in which the variable is involved (contains 
 * the pointers (id's) to them). 
 */
struct s_VariableInfo
{
  int  vid;       // DCOP var id 
  int  domain_size;
  int* domain;
  int  constr_size;
  int* constr_id; // idx of ConstrInfo ARRAY associated to current Info
};

/* The array of VarInfo stores the Current Agent Scope.
 * Varialbes are listed in the following order:
 * Init-variable | Sampling-Variables 
 * Within the two subsets variables are sorted based on their ID in 
 * ascending order.
 */
extern __device__ s_VariableInfo *g_devAgentVarInfo;
extern __device__ int g_devAgentScope_size;
extern __device__ int g_devAgentInVar_size;
extern            s_VariableInfo *g_hostAgentVarInfo; /* Aux (host) */
extern            int g_hostAgentScope_size; /* Aux (host) */
extern            int g_hostAgentInVar_size; /* Aux (host) */

/*
 * Each relation, associated to a constraint which within all 
 * and only variables held by this agent, has an entry in this struct.
 * For each relation it describes its arity, scope, the tuples
 * (values for each variable in the order listed in 'scope') associated
 * to the cost.
 * The ONLY binary version of the solver is optimized to store the costs  
 * in a MATRIX representation, so to be able to retrieve values in O(1).
 * When a tuple (i,j) is not present in a relation we set the position
 * of the corresponding costs matrix to the MACRO NO_RELATION_EXISTS
 */
struct s_ConstraintInfo
{
  // int cid = position
  int* scope;		    // index of g_hostAgentVarInfo
  int  arity;		    // = 2
  int* tuples;		    // this is NOT used in the BINARY version.
  int  numof_tuples;	    // 
  int* costs;		    // the actual CONSTRAINT GRAPH (size: |D| x |D|)
  int  def_cost;
};
extern __device__ s_ConstraintInfo *g_devAgentConstrInfo;
extern __device__ int g_devAgentConstrInfo_size;


extern __device__ int* g_devAgentConstrIDs;
extern __device__ int  g_devAgentConstrIDs_size;
extern            int  g_hostAgentConstrIDs_size;

// deprecated?
extern __device__ double* gd_Zcomponents;
extern __device__ int  gd_Zcomponents_size;
extern __device__ double* gd_Zinv;
extern __device__ int  gd_Zinv_size;
//-

extern size_t g_global_memory_allocated;


#endif
