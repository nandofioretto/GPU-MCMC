#ifndef DEVICE_UTILS_H
#define DEVICE_UTILS_H

#include <stdio.h>
#include <string.h>
#include "dev_globals.h"

namespace dev_utils
{

  int get_max_utility_value( );
  __global__ void _g_get_max_utility_value( int* utility );

  void get_best_sample(int* hostBestSample, int size );

  void computeJointUtility( int samples, int nSeeds );

  void setPRNGs( int samples, curandState* devStates, int nSeeds );

  __global__ void dump_gd_outvals(); 
  __global__ void dump_gd_outvals_best();

  void get_AllSamples( int *outsample, int size, int X, int nSeeds);


  // Utility class used to avoid linker errors with extern
  // unsized shared memory arrays with templated type
  template<class T>
    struct SharedMemory
    {
      __device__ inline operator T *()
      {
	extern __shared__ int __smem[];
        return (T *)__smem;
      }
      
      __device__ inline operator const T *() const
      {
        extern __shared__ int __smem[];
        return (T *)__smem;
      }
    };

  // specialize for double to avoid unaligned memory
  // access compile errors
  template<>
    struct SharedMemory<double>
    {
      __device__ inline operator       double *()
      {
        extern __shared__ double __smem_d[];
        return (double *)__smem_d;
      }
      
      __device__ inline operator const double *() const
      {
        extern __shared__ double __smem_d[];
        return (double *)__smem_d;
      }
    };
  
 
};

#endif
