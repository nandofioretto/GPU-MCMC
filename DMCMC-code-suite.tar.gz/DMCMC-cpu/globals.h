#ifndef GLOBALS_H
#define GLOBALS_H

/* Common dependencies */
#include <stdlib.h> // for atoi
#include <stdio.h>
#include <sys/time.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

/* Input/Output */
#include <iomanip>
#include <iostream>
#include <fstream>
#include <sstream>

/* Arithmetic and Assertions */
#include <cassert>
#include <cmath>
#include <limits>

/* STL dependencies */
#include <algorithm>
#include <iterator>
#include <map>
#include <queue>
#include <stack>
#include <set>
#include <string>
#include <vector>
#include <utility>

#include "statistics.h"

 
class Agent;
class Domain;
class var_int;
class Relation;
class Constraint;
class Statistics;

#define INFTY 2147483647 // LONG_MAX (2^31-1)
#define INFTY_STR "2147483647"
#define NO_RELATION_EXISTS -2147483647

extern std::map< std::string, Agent* >      g_agents;
extern std::map< std::string, Domain* >     g_domains;
extern std::map< std::string, var_int* >    g_variables;
extern std::map< std::string, Relation* >   g_relations;
extern std::map< std::string, Constraint* > g_constraints;

extern std::map<Agent*, std::vector<Agent*> > g_agent_neighbours;

extern Statistics* g_stats;

extern int g_solution;
extern unsigned int g_dom_c;

static std::string itos( int i )
{
    std::stringstream ss;
    std::string s;
    ss << i;
    ss >> s;
    return s;
}

static int stoi( std::string s )
{
    std::stringstream ss;
    int i;
    ss << s;
    ss >> i;
    return i;
}


#endif
