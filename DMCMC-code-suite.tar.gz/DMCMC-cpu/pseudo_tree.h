#ifndef PSEUDO_TREE_H
#define PSEUDO_TREE_H

#include "globals.h"

class Agent;
class PseudoNode;

class PseudoTree
{
 private:
  std::map< PseudoNode*, bool > _unlockedNodes; // nodes unlocked.
  // a node is unlocked if all its pseudo-children are unlocked
  // and it has compleated the Gibbs Sampling process
  std::map< Agent*, int > _MarkedAgents;
  void _dfsStep( PseudoNode* curr_node );

 public:
  PseudoTree();
  ~PseudoTree();

  std::vector<PseudoNode*> getNodessReadyToSample();
  void unlockNode( PseudoNode* N );

};//-


#endif
