#include <math.h> 

#include "globals.h"
#include "message.h"
#include "agent.h"
#include "domain.h"
#include "constraint.h"
#include "relation.h"
#include "var_int.h"

using namespace std;

long int select_best(long int a, long int b, bool _optMax)
{
  if( _optMax )
    if (a > b) return a; else return b;
  else
    if (a < b) return a; else return b;
}//-

long int select_worst(long int a, long int b, bool _optMax)
{
  if( _optMax )
    if (a < b) return a; else return b;
  else
    if (a > b) return a; else return b;
}//-

Message::Message()
  : _sender( NULL ), _recver( NULL )
{
}//-

Message::~Message()
{ }//-

Message::Message( const Message& other )
{
  _header_sep_vars = other._header_sep_vars;
  _VALUE_msg = other._VALUE_msg;
  _sender = other._sender;
  _recver = other._recver;
}//-

Message& Message::operator=( const Message& other )
{
  if( this != &other )
  {
    _header_sep_vars = other._header_sep_vars;
    _VALUE_msg = other._VALUE_msg;
    _sender = other._sender;
    _recver = other._recver;
    
  }
  return *this;
}//-

Agent* Message::get_sender() 
{
  return _sender;
}//-

Agent* Message::get_recver()
{
  return _recver;
}//-

bool Message::is_empty()
{
  return _VALUE_msg.empty();
}//-


void Message::set_header( Agent* sender, 
			  Agent_con parent, vector<Agent_con> ancestors)
{
  _sender = sender;
  _recver = parent.first;

  // Insert variables involving constraints of sender and direct ancestors
  set< var_int* > SEP;
  vector< var_int* > P = parent.first->get_input_vars_in( parent.second );
  SEP.insert( P.begin(), P.end() );
  
  for( int i = 0; i < ancestors.size(); i++ )
  {
    vector< var_int* > A = 
      ancestors[ i ].first->get_input_vars_in( ancestors[ i ].second );
    SEP.insert( A.begin(), A.end() );
  }
  
  // Insert variables coming from headers of descendant agents
  for ( int i = 0; i < sender->n_children(); i++ )
  {
    Message* M = sender->get_received_VALUE_msg( i );
    for( long int k = 0; k < M->header_size(); k++ )
      SEP.insert( M->get_header()[ k ] );
  }

  // Remove input variables of sender
  vector< var_int* > sender_in = sender->get_input_vars();
  for( long int i = 0; i < sender_in.size(); i++ )
  {
    SEP.erase( sender_in[ i ] );
  }
  
  // Save
  set< var_int* >::iterator it;
  for( it = SEP.begin(); it != SEP.end(); ++it )
  {
    _header_sep_vars.push_back( *it );
  }

}//-


vector<var_int*> Message::get_header()
{
  return _header_sep_vars;
}//-

long int Message::header_size()
{
  return _header_sep_vars.size();;
}//-

// Assumption: query has same size as numof_vars_in_VALUE_msg 
long int Message::get_utility( vector<int> query, int D )
{
  long int row  = 0;
  for( int i = 0; i < query.size(); i++ )
  {
    row += query[ i ] * pow( D, (double)query.size() - (i+1) );
  }
  return _VALUE_msg[ row ];
}//-

/*
 * Retrieve the tuple associated to the values matching In_vars and 
 * Sep_vars involved in the constraint C 
 * note: both in_vars and sep_vars are lexicographically sorted
 */ 
void Message::get_query( vector<int>& query, vector<var_int*> query_vars, 
			 int D,
			 vector<var_int*> Sep_vars, long int sep_row, 
			 vector<var_int*> In_vars,  long int in_row, bool normalize )
{

  for( int v = 0; v < query_vars.size(); v++ )
  {
    for( int i = 0; i < In_vars.size(); i++) 
    {
      if ( In_vars[ i ] == query_vars[ v ] )
      {
	int p = In_vars.size() - (i+1);
	query[ v ] = 
	  (int)( in_row / pow(D, (double)p) ) % D;
	if( normalize ) query[ v ] += query_vars[ v ]->domain->get_min();
	break;
      }
    }

    for( int s = 0; s < Sep_vars.size(); s++) 
    {
      if ( Sep_vars[ s ] == query_vars[ v ] )
      {
	int p = Sep_vars.size() - (s+1);
	query[ v ] = 
	  (int)( sep_row / pow(D, (double)p) ) % D;
	if( normalize ) query[ v ] += query_vars[ v ]->domain->get_min();
	break;
      }
    }
  }
}//-

/*
 * Retrieve the tuple associated to the values matching In_vars and 
 * Sep_vars involved in the constraint C 
 * note: both in_vars and sep_vars are lexicographically sorted
 */ 
void Message::get_query( vector<int>& query, var_int** query_vars, 
			 int query_vars_size, int D,
			 vector<var_int*> Sep_vars, long int sep_row, 
			 vector<var_int*> In_vars,  long int in_row, bool normalize )
{
  for( int v = 0; v < query_vars_size; v++ )
  {
    for( int i = 0; i < In_vars.size(); i++) 
    {
      if ( In_vars[ i ] == query_vars[ v ] )
      {
	int p = In_vars.size() - (i+1);
	query[ v ] = 
	  (int)( in_row / pow(D, (double)p) ) % D;
	if( normalize ) query[ v ] += query_vars[ v ]->domain->get_min();
	break;
      }
    }

    for( int s = 0; s < Sep_vars.size(); s++) 
    {
      if ( Sep_vars[ s ] == query_vars[ v ] )
      {
	int p = Sep_vars.size() - (s+1);
	query[ v ] = 
	  (int)( sep_row / pow(D, (double)p) ) % D;
	if( normalize ) query[ v ] += query_vars[ v ]->domain->get_min();
	break;
      }
    }
  }
}//-

long int Message::util_of_recv_VALUE_msgs(vector<var_int*> invars_A, long int i_a, 
					  vector<var_int*> invars_pA, long int i_pa )
{
  int D = _sender->get_var(0)->domain->size();
  vector<int> query;
  long int util = 0;

  for( int i = 0; i < _sender->n_children(); i++)
  {
    Message *M = _sender->get_received_VALUE_msg( i );
    query.resize( M->header_size() );    

    get_query( query, M->get_header(), D,
	       invars_pA, i_pa, invars_A, i_a, false );	// efficiency::ok

    long int _util_ = M->get_utility( query, D ); // efficiency::ok
    if(_util_ == -INFTY || _util_ == INFTY ) return _util_;
    util += _util_;
  }
  return util;
}//-

long int Message::util_of_constrs (vector< Constraint* > constr_S_R, 
			      vector<var_int*> invars_S, long int i_s,
			      vector<var_int*> invars_R, long int i_r )
{
  int D = _sender->get_var(0)->domain->size();
  vector<int> query;
  long int _util_; long int util = 0;

  for( int c = 0; c < constr_S_R.size(); c++ )
  {
    Relation* R = constr_S_R[ c ]->ref_relation();
    int R_arity = constr_S_R[ c ]->get_arity();    
	
    // HACK! Check Hard constraints here!
    query.resize( R_arity );
    get_query( query, constr_S_R[ c ]->get_scope(), R_arity, D,
	       invars_R, i_r, invars_S, i_s, true ); // efficiency::ok
    _util_ = R->get_cost( query );		     // efficiency::ok
    if(_util_ == -INFTY || _util_ == INFTY ) return _util_;
    util += _util_;
  }
  return util;
}//-

void Message::make( Agent *sender, Agent_con parent, vector<Agent_con> ancestors )
{
  int D = sender->get_var(0)->domain->size();
  long int worst_util = select_worst(INFTY, -INFTY, sender->get_opt());
  long int util, best_util, _util_;
  vector< var_int* > sender_Iv = sender->get_input_vars();

  var_int** sep_vars = new var_int*[ _header_sep_vars.size() ];
  for(int i = 0; i < _header_sep_vars.size(); i++) 
  {
    sep_vars[ i ] = _header_sep_vars[ i ];
  }

  long int sender_Nperm  = pow(D, (double)sender_Iv.size() );
  long int recver_Nperm  = pow(D, (double)_header_sep_vars.size() );
  _VALUE_msg.resize( recver_Nperm ); // result;

  
  vector< vector< Constraint* > > sender_constrs;
  sender_constrs.push_back( parent.second );
  for(int i = 0; i < ancestors.size(); i++ )
    sender_constrs.push_back( ancestors[ i ].second );
 
  for( long int i_r = 0; i_r < recver_Nperm; i_r++ )
  {
    best_util = worst_util; 
    for( long int i_s = 0; i_s < sender_Nperm; i_s++ )
    {
      _util_ = sender->get_best_sample_util( i_s );
      if( _util_ == -INFTY || _util_ == INFTY ) { /*best_util = _util_;*/ continue; }
      util = _util_;

      // CONSTRAINTS: sender with PARENT and direct ANCESTORS
      for( long int c = 0; c < sender_constrs.size(); c++ )
      {
	_util_ = 
	  util_of_constrs( sender_constrs[ c ], sender_Iv, i_s, _header_sep_vars, i_r );
	if( _util_ == -INFTY || _util_ == INFTY ) { break; }
	util += _util_;
      }
      if( _util_ == -INFTY || _util_ == INFTY ) { /*best_util = _util_; */continue; }


      // PSEUDO-CHILDREN  Retrieve Utils from the pseudo-children messages of A
      _util_ = util_of_recv_VALUE_msgs( sender_Iv, i_s, _header_sep_vars, i_r );

      if( _util_ == -INFTY || _util_ == INFTY ) { /*best_util = _util_; */continue; }
      util += _util_;

      best_util = select_best( best_util, util, sender->get_opt() );	
    }

    _VALUE_msg[ i_r ] = best_util;
    if( _sender->is_root() ) g_stats->set_best_utility( best_util );
  }
  delete[] sep_vars;

}//-
