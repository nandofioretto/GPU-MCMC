
java -cp frodo2.jar ch.epfl.lia.frodo.algorithms.AgentFactory $1 $2 -timeout 0 | egrep "cost:|finished"
