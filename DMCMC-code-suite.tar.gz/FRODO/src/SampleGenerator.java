import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

/**
 * Created by IntelliJ IDEA.
 * User: 
 * Date: 8/25/11
 * Time: 4:05 AM
 * To change this template use File | Settings | File Templates.
 */
public class SampleGenerator {
    public static void main(String asdf[]) throws IOException {
        int rowNumber = Integer.parseInt(asdf[0]);
        int columnNumber = Integer.parseInt(asdf[1]);
        Random random = new Random();
        FileWriter output = new FileWriter("test.xcsp");

        output.append("<instance>\n" +
                "<presentation name=\"sampleProblem\" maxConstraintArity=\"2\"\n" +
                "maximize=\"false\" format=\"XCSP 2.1_FRODO\" />\n");

        output.append("<agents nbAgents=\"" + String.valueOf(rowNumber * columnNumber) + "\">\n");
        for (int i = 0; i < rowNumber; i++)
            for (int j = 0; j < columnNumber; j++) {
                output.append("<agent name=\"agent" + String.format("%d%d", i, j) + "\" />\n");
            }
        output.append("</agents>\n");
        output.append("<domains nbDomains=\"1\">\n" +
                "<domain name=\"moves\" nbValues=\"5\">0..4</domain>\n" +
                "</domains>\n");

        output.append("<variables nbVariables=\"" + String.valueOf(rowNumber * columnNumber) + "\">\n");
        for (int i = 0; i < rowNumber; i++)
            for (int j = 0; j < columnNumber; j++) {
                output.append("<variable name=\"X" + String.format("%d%d", i, j) + "\" domain=\"moves\" agent=\"agent"
                        + String.format("%d%d", i, j) + "\" />\n");
            }


        output.append("</variables>\n");
        output.append("<relations nbRelations=\"" + String.valueOf(rowNumber * columnNumber * 2 - rowNumber - columnNumber) + "\">");

        for (int i = 0; i < rowNumber; i++)
            for (int j = 0; j < columnNumber; j++) {
                if (i < rowNumber - 1) {
                    output.append("\n<relation name=\"X" + String.format("%d%d", i, j) + "X" + String.format("%d%d", i + 1, j)
                            + "\" arity=\"2\" nbTuples=\"25\" semantics=\"soft\" defaultCost=\""
                            + String.format("%.5f",random.nextDouble() * 5.1) +  "\">\n");

                    relation(output, i, j, i + 1, j, rowNumber, columnNumber, random);

                    output.append("\n</relation>\n");
                }

                if (j < columnNumber - 1) {
                    output.append("<relation name=\"X" + String.format("%d%d", i, j) + "X" + String.format("%d%d", i, j + 1)
                            + "\" arity=\"2\" nbTuples=\"25\" semantics=\"soft\" defaultCost=\""
                            + String.format("%.5f",random.nextDouble() * 5.1)  + "\">\n");

                    relation(output, i, j, i, j + 1, rowNumber, columnNumber, random);

                    output.append("\n</relation>");
                }
            }

        output.append("\n</relations>\n");
        output.append("<constraints nbConstraints=\"" + String.valueOf(rowNumber * columnNumber * 2 - rowNumber - columnNumber) + "\">\n");
        for (int i = 0; i < rowNumber; i++)
            for (int j = 0; j < columnNumber; j++) {
                if (i < rowNumber - 1)
                    output.append("<constraint name=\"" + "X" + String.format("%d%d", i, j) + "_and_X"
                            + String.format("%d%d", i + 1, j) + "_signals\" arity=\"2\" scope=\""
                            + "X" + String.format("%d%d", i, j) + " X" + String.format("%d%d", i + 1, j) + "\" reference=\"" + "X" + String.format("%d%d", i, j) + "X" + String.format("%d%d", i + 1, j) + "\" />");
                if (j < columnNumber - 1)
                    output.append("<constraint name=\"" + "X" + String.format("%d%d", i, j) + "_and_X"
                            + String.format("%d%d", i, j + 1) + "_signals\" arity=\"2\" scope=\""
                            + "X" + String.format("%d%d", i, j) + " X" + String.format("%d%d", i, j + 1) + "\" reference=\"" + "X" + String.format("%d%d", i, j) + "X" + String.format("%d%d", i, j + 1) + "\" />");
            }

        output.append("\n</constraints>\n" +
                "</instance>");
        output.close();
    }

    private static void relation(FileWriter output, int i, int j, int i1, int j1, int rowNumber, int columnNumber, Random random) throws IOException {

        int index[][] = new int[5][5];
        if((i == 0)||(i == rowNumber - 1)||(j == 0)||(j == columnNumber - 1)||(j1 == columnNumber - 1)||(i1 == rowNumber - 1)){

        output.append("infinity: ");

        if ((i == 0))
            for (int k = 0; k <= 4; k++) {
                output.append(String.valueOf(1) + " " + String.valueOf(k) + "| \n");
                index[1][k] = 1;
            }

        if ((i == rowNumber - 1))
            for (int k = 0; k <= 4; k++) {
                output.append(String.valueOf(3) + " " + String.valueOf(k) + "| \n");
                index[3][k] = 1;
            }


        if ((j == 0))
            for (int k = 0; k <= 4; k++) {
                output.append(String.valueOf(4) + " " + String.valueOf(k) + "| \n");
                index[4][k] = 1;
            }

        if ((j == columnNumber - 1))
            for (int k = 0; k <= 4; k++) {
                output.append(String.valueOf(2) + " " + String.valueOf(k) + "| \n");
                index[2][k] = 1;
            }

        //-----------------------------------------------------------------------------


        if ((i1 == rowNumber - 1)) {
            for (int h = 0; h <= 4; h++) {
                if (index[h][3] == 0) {
                    output.append(String.valueOf(h) + " " + String.valueOf(3) + "| \n");
                    index[h][3] = 1;
                }
            }


            if ((j1 == columnNumber - 1))
                for (int h = 0; h <= 4; h++)
                    if (index[h][2] == 0) {
                        output.append(String.valueOf(h) + " " + String.valueOf(2) + "| \n");
                        index[h][2] = 1;
                    }

            if ((j1 == 0))
                for (int h = 0; h <= 4; h++)
                    if (index[h][4] == 0) {
                        output.append(String.valueOf(h) + " " + String.valueOf(4) + "| \n");
                        index[h][4] = 1;
                    }
        }
        }


        if ((j1 == columnNumber - 1)) {
            for (int h = 0; h <= 4; h++)
                if (index[h][2] == 0) {
                    output.append(String.valueOf(h) + " " + String.valueOf(2) + "| \n");
                    index[h][2] = 1;
                }

            if ((i1 == rowNumber - 1))
                for (int h = 0; h <= 4; h++)
                    if (index[h][3] == 0) {
                        output.append(String.valueOf(h) + " " + String.valueOf(3) + "| \n");
                        index[h][3] = 1;
                    }

            if ((i1 == 0))
                for (int h = 0; h <= 4; h++)
                    if (index[h][1] == 0) {
                        output.append(String.valueOf(h) + " " + String.valueOf(1) + "| \n");
                        index[h][1] = 1;
                    }
        }


        boolean first = true;
        for (int h = 0; h <= 4; h++)
            for (int k = 0; k <= 4; k++)
                if ((index[h][k] == 0) && (first == false))
                    output.append("|\n" + String.format("%.5f",random.nextDouble() *distance(h,k)) + ": "
                            + String.valueOf(h) + " " + String.valueOf(k));
                else if((index[h][k] == 0) && (first == true)){
                    output.append(String.format("%.5f",random.nextDouble()*distance(h,k)) + ": "
                            + String.valueOf(h) + " " + String.valueOf(k));
                    first=false;
                }
    }

    private static double distance(int h, int k){
        double x[]=new double[2];
        double y[]=new double[2];
        x[0]=0;
        x[1]=0;
        y[0]=5.1;
        y[1]=0;

        switch (h){
            case 1:  x[1]+=1.1;       break;
            case 2:  x[0]+=1.1;         break;
            case 3: x[1]-=1.1;       break;
            case 4: x[0]-=1.1; break;
        }

        switch (k){
            case 1:  y[1]+=1.1;       break;
            case 2:  y[0]+=1.1;         break;
            case 3: y[1]-=1.1;       break;
            case 4: y[0]-=1.1; break;
        }

        double distance=10.2-Math.sqrt((x[0]-y[0])*(x[0]-y[0])+((x[1]-y[1])*(x[1]-y[1])));
        return distance;
    }
}
