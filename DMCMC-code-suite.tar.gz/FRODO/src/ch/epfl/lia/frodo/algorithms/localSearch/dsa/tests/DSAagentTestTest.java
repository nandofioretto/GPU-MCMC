package ch.epfl.lia.frodo.algorithms.localSearch.dsa.tests;

/**
 * Created with IntelliJ IDEA.
 * User: tranguyen
 * Date: 7/10/12
 * Time: 11:28 AM
 * To change this template use File | Settings | File Templates.
 */
public class DSAagentTestTest {
}
