/*
FRODO: a FRamework for Open/Distributed Optimization
Copyright (C) 2008-2012  Thomas Leaute, Brammert Ottens & Radoslaw Szymanek

FRODO is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

FRODO is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.


How to contact the authors: 
<http://lia.epfl.ch/>

EPFL / IC / IIF / LIA
Batiment IN 
Station 14 
CH - 1015 Lausanne 
Switzerland
 */

/**
 * 
 */
package ch.epfl.lia.frodo.algorithms.localSearch.mgm.mgm2;

import java.util.ArrayList;

import ch.epfl.lia.frodo.communication.MessageWith4Payloads;
import ch.epfl.lia.frodo.solutionSpaces.Addable;

/**
 * @author Brammert Ottens, 29 mrt. 2011
 * @param <Val> type used for domain values
 * @param <U> type used for utilitie values
 * 
 */
public class OFFERold <Val extends Addable<Val>, U extends Addable<U>>
		extends
		MessageWith4Payloads<String, String, ArrayList<BinaryAssignment<Val>>, ArrayList<U>> {
	
	/** Empty constructor used for externalization */
	public OFFERold () { }

	/**
	 * Constructor
	 * 
	 * @param sender		the sender of the message
	 * @param receiver		the receiver of the message
	 * @param assignments	the list of assignments
	 * @param utilities		the gain for each of the assignments
	 */
	public OFFERold(String sender, String receiver, ArrayList<BinaryAssignment<Val>> assignments, ArrayList<U> utilities) {
		super(MGM2.OFFER_MSG_TYPE, sender, receiver, assignments, utilities);
		assert !sender.equals(receiver);
	}
	
	/**
	 * @author Brammert Ottens, 29 mrt. 2011
	 * @return the sender of the message
	 */
	public String getSender() {
		return this.getPayload1();
	}
	
	/**
	 * @author Brammert Ottens, 29 mrt. 2011
	 * @return the receiver of the message
	 */
	public String getReceiver() {
		return this.getPayload2();
	}
	
	/**
	 * @author Brammert Ottens, 29 mrt. 2011
	 * @return the list of assignments
	 */
	public ArrayList<BinaryAssignment<Val>> getAssignments() {
		return this.getPayload3();
	}
	
	/**
	 * @author Brammert Ottens, 29 mrt. 2011
	 * @return the gain for each of the assignments
	 */
	public ArrayList<U> getUtilities() {
		return this.getPayload4();
	}

}
