/*
FRODO: a FRamework for Open/Distributed Optimization
Copyright (C) 2008-2012  Thomas Leaute, Brammert Ottens & Radoslaw Szymanek

FRODO is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

FRODO is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.


How to contact the authors: 
<http://lia.epfl.ch/>

EPFL / IC / IIF / LIA
Batiment IN 
Station 14 
CH - 1015 Lausanne 
Switzerland
*/

package ch.epfl.lia.frodo.algorithms.adopt;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import ch.epfl.lia.frodo.communication.Message;
import ch.epfl.lia.frodo.solutionSpaces.Addable;

/**
 * The message used to send a VALUE message to a variable's
 * children
 * 
 * @param <Val> the type used for variable values
 * @param <U> the type used for utility values
 */
public class PastUPDATEmsg
		extends Message implements Externalizable {

	/** The sending variable */
	private String sender;

	/** The receiving variable */
	String receiver;

	/** The context in which this message was created */
	private int UPDATE;

	
	public String getSender() {
		return sender;
	}

	public void setSender(String sender) {
		this.sender = sender;
	}

	public String getReceiver() {
		return receiver;
	}

	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}

	public int getUPDATE() {
		return UPDATE;
	}

	public void setUPDATE(int uPDATE) {
		UPDATE = uPDATE;
	}

	/** Empty constructor */
	public PastUPDATEmsg () {
		super (ADOPT.Original.PAST_MSG_TYPE);
	}

	/**
	 * Constructor
	 * 
	 * @param sender the sender variable
	 * @param receiver the recipient variable
	 * @param value the context
	 */
	public PastUPDATEmsg(String sender, String receiver, int UPDATE) {
		super(ADOPT.Original.INITIAL_MSG_TYPE);
		this.sender = sender;
		this.receiver = receiver;
		this.UPDATE = UPDATE;
	}
	


	/** @see java.io.Externalizable#writeExternal(java.io.ObjectOutput) */
	public void writeExternal(ObjectOutput out) throws IOException {
		out.writeObject(this.sender);
		out.writeObject(this.receiver);
		out.writeObject(this.UPDATE);
	}

	/** @see java.io.Externalizable#readExternal(java.io.ObjectInput) */
	@SuppressWarnings("unchecked")
	public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
		this.sender = (String) in.readObject();
		this.receiver = (String) in.readObject();
		this.UPDATE = (Integer) in.readObject();
	}

	/** Used for serialization */
	private static final long serialVersionUID = 2153239219905600645L;



}