/*
FRODO: a FRamework for Open/Distributed Optimization
Copyright (C) 2008-2012  Thomas Leaute, Brammert Ottens & Radoslaw Szymanek

FRODO is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

FRODO is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.


How to contact the authors: 
<http://lia.epfl.ch/>

EPFL / IC / IIF / LIA
Batiment IN 
Station 14 
CH - 1015 Lausanne 
Switzerland
 */

package ch.epfl.lia.frodo.algorithms.localSearch.mgm;

import ch.epfl.lia.frodo.communication.MessageWith2Payloads;
import ch.epfl.lia.frodo.solutionSpaces.Addable;

/** A message holding an assignment to a variable
 * @param <V> type used for variable values
 */
public class AssignmentMessage <V extends Addable<V>> extends MessageWith2Payloads<String, V> {

	/** Empty constructor used for externalization */
	public AssignmentMessage () { }

	/** Constructor 
	 * @param var 		the variable
	 * @param val 		the value assigned to the variable \a var
	 */
	public AssignmentMessage (String var, V val) {
		super (MGM.OUTPUT_MSG_TYPE, var, val);
	}

	/** @return the variable */
	public String getVariable () {
		return this.getPayload1();
	}

	/** @return the value */
	public V getValue () {
		return this.getPayload2();
	}

}
