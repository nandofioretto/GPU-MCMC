/*
FRODO: a FRamework for Open/Distributed Optimization
Copyright (C) 2008-2012  Thomas Leaute, Brammert Ottens & Radoslaw Szymanek

FRODO is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

FRODO is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.


How to contact the authors: 
<http://lia.epfl.ch/>

EPFL / IC / IIF / LIA
Batiment IN 
Station 14 
CH - 1015 Lausanne 
Switzerland
*/

package ch.epfl.lia.frodo.communication;

import java.io.IOException;
import java.io.ObjectStreamClass;
import java.io.OutputStream;

/** An optimized implementation of ObjectOutputStream that minimizes the overhead of serializing class descriptions
 * @author Thomas Leaute
 */
public class ObjectOutputStream extends java.io.ObjectOutputStream {

	/** Constructor
	 * @param out 			output stream to write to
	 * @throws IOException 	if an I/O error occurs while writing stream header
	 */
	public ObjectOutputStream(OutputStream out) throws IOException {
		super(out);
	}

	/** @see java.io.ObjectOutputStream#writeClassDescriptor(java.io.ObjectStreamClass) */
	protected void writeClassDescriptor (ObjectStreamClass desc) throws IOException {
		
		String className = desc.getName();
		
		// Strip FRODO's stupidly long package name if possible
		if (className.startsWith("ch.epfl.lia.frodo")) 
			className = className.substring(12);
		
		this.writeUTF(className);
	}
	
}
