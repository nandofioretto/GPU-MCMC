/*
FRODO: a FRamework for Open/Distributed Optimization
Copyright (C) 2008-2012  Thomas Leaute, Brammert Ottens & Radoslaw Szymanek

FRODO is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

FRODO is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.


How to contact the authors: 
<http://lia.epfl.ch/>

EPFL / IC / IIF / LIA
Batiment IN 
Station 14 
CH - 1015 Lausanne 
Switzerland
*/

package ch.epfl.lia.frodo.communication.tcp;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;

import ch.epfl.lia.frodo.communication.AgentAddress;
import ch.epfl.lia.frodo.communication.PipeFactory;
import ch.epfl.lia.frodo.communication.Queue;
import ch.epfl.lia.frodo.communication.QueueInputPipeInterface;
import ch.epfl.lia.frodo.communication.QueueOutputPipeInterface;

/**
 * @author Xavier Olive
 * This factory implements tcp pipes
 */
public class TCPPipeFactory implements PipeFactory {
	
	/** @see ch.epfl.lia.frodo.communication.PipeFactory#inputPipe(ch.epfl.lia.frodo.communication.Queue, ch.epfl.lia.frodo.communication.AgentAddress, java.lang.Integer) */
	public QueueInputPipeInterface inputPipe(Queue queue, AgentAddress address, Integer maxNbrConnections) throws IOException {
		TCPAddress newAddress = (TCPAddress) address;
		return new QueueInputPipeTCP(queue, newAddress.getPort(), maxNbrConnections);
	}
	
	/** @see ch.epfl.lia.frodo.communication.PipeFactory#inputPipe(ch.epfl.lia.frodo.communication.Queue, ch.epfl.lia.frodo.communication.AgentAddress) */
	public QueueInputPipeInterface inputPipe(Queue queue, AgentAddress address) throws IOException {
		TCPAddress newAddress = (TCPAddress) address;
		return new QueueInputPipeTCP(queue, newAddress.getPort());
	}

	/** @see ch.epfl.lia.frodo.communication.PipeFactory#outputPipe(ch.epfl.lia.frodo.communication.AgentAddress) */
	public QueueOutputPipeInterface outputPipe(AgentAddress address) throws UnknownHostException, IOException {
		TCPAddress newAddress = (TCPAddress) address;
		return new QueueOutputPipeTCP(newAddress.getAddress(),newAddress.getPort());
	}

	/** @see ch.epfl.lia.frodo.communication.PipeFactory#outputPipe(ch.epfl.lia.frodo.communication.AgentAddress, ch.epfl.lia.frodo.communication.AgentAddress) */
	public QueueOutputPipeInterface outputPipe(AgentAddress address, AgentAddress rawDataAddress) throws UnknownHostException, IOException {
		TCPAddress newAddress = (TCPAddress) address;
		TCPAddress newRawAddress = (TCPAddress) rawDataAddress;
		return new QueueOutputPipeTCP(newAddress.getAddress(),newAddress.getPort(),newRawAddress.getAddress(),newRawAddress.getPort());
	}

	/** @see ch.epfl.lia.frodo.communication.PipeFactory#getSelfAddress(int) */
	public AgentAddress getSelfAddress(int idx) {
		try {
			return new TCPAddress(InetAddress.getLocalHost().getCanonicalHostName(),idx);
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	
	
}
